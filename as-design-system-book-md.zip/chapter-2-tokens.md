# Chapter 2: Tokens, or How Values Become a System

> **Draft 1.** All numbers and code come from the AS Design System repository. Items marked **[AUTHOR NOTE]** are places for your own story or opinion.

---

## A token is a decision with a name

Open any stylesheet that has grown for a few years and search for the colour `#1e3969`. You'll probably find it dozens of times, and nobody remembers whether they all mean "the brand colour" or whether some of them are "that shade of blue that looked good next to the logo".

A design token solves this by separating the **decision** from the **value**. Instead of `#1e3969`, a component says `var(--as-color-accent)`. The decision ("this is the accent colour") lives in one place. The value can change without anyone hunting through the stylesheets.

That is all a token is: a named decision. In the AS Design System tokens are plain CSS custom properties, declared once on `:root` and consumed everywhere with `var()`. There is no token build pipeline and no JSON-to-CSS transform. What makes them a *system* rather than a pile of variables is how they're named, how they relate to each other, and how consistently they're used.

This chapter looks at all three, using the real tokens, and then does something most design system books skip: it audits how well the tokens are actually used.

**[AUTHOR NOTE: A sentence or two on why you chose plain CSS custom properties over a token tool like Style Dictionary. Was it the "no build step for the consumer" principle from Chapter 1?]**

---

## The inventory

The documentation site lists **165 tokens in 11 categories**:

| Category | Documented tokens |
|---|---|
| Icons | 70 |
| Colors | 32 |
| Z-Index | 12 |
| Size | 10 |
| Border radius | 7 |
| Space | 7 |
| Font size | 7 |
| Time | 6 |
| Line height | 6 |
| Font family | 5 |
| Ratio | 3 |

Two things stand out before we read a single value.

First, **icons are 42% of the total.** They're tokens, which is unusual and worth its own section below.

Second, the number of tokens *declared* in the CSS is higher than the number *documented*. The token stylesheet declares about 110 non-icon custom properties, while the docs cover 95. A handful, such as `--as-box-shadow`, `--as-timing-function-1`, `--as-base` and `--as-color-lightness-factor`, are in use but not on the site. We'll come back to why that gap matters in the audit.

---

## Three layers of naming

The system uses custom properties at three distinct levels. It isn't formally declared anywhere, but the pattern is consistent enough to name.

### Layer 1: The raw palette

At the top of `as-tokens-component.css`:

```css
--dark_cornflower_blue: #1E3969;
--indigo_dye: #153B50;
--cadet_blue: #429EA6;
--powder_blue: #C0DCDE;
--ruby_red: #9A031E;
--pumpkin: #F56F16;
```

These are named after what the colour *looks like*: a cornflower blue, a ruby red. The file marks them as "OLD colours", the original palette from before the semantic layer existed. They describe appearance and say nothing about purpose.

### Layer 2: Semantic tokens

```css
--as-color-accent: #1e3969;
--as-color-text: #153b50;
--as-color-background-panel: #ffffff;
--as-color-status-error: #9A031E;
--as-color-status-warning: #F56F16;
```

These are named after what the colour is **for**. `--as-color-status-error` happens to be ruby red today, but the name promises only that it's the error colour. If the brand changes, you change the value and every error message follows.

The naming pattern is regular enough to read:

```
--as-{category}-{role}-{variant}

--as-color-background-button-weak
 │    │       │         │      └── variant: strong / weak
 │    │       │         └───────── subject: button
 │    │       └─────────────────── role: background
 │    └─────────────────────────── category: color
 └──────────────────────────────── namespace
```

The `as-` prefix guards against collisions with other stylesheets on the page. That matters a great deal in the light-DOM world from Chapter 1, where your tokens share a global namespace with everything else.

**The rule of thumb:** a semantic name should survive a rebrand. `--as-color-text-button` survives. `--as-color-blue` doesn't.

### Layer 3: Component-local variables

The third layer isn't in the token file at all. Components declare their own private custom properties and point them at global tokens:

```css
/* as-select-multiple-component.css */
--color-active-darker: var(--as-color-accent);
--color-active-dark:   var(--as-color-accent-strong);
```

Notice there's no `--as-` prefix. These are local, which is a signal to readers: *don't set this from outside*. The same pattern appears in the toast (`--delay`, set from JavaScript to drive its countdown animation), the command menu (`--z-index`) and the icon (`--icon`).

This layering is the standard shape of a mature token system: **raw values → semantic roles → component hooks**. Each layer can change independently. Rebrand? Change layer 2. Restyle one component? Change layer 3.

---

## Colour: one value, derived variants

The most interesting engineering in the token file is how colour variants are produced. Rather than hand-picking a "darker" and "lighter" version of every colour, the system **derives** them:

```css
--as-color-lightness-factor: 10;

--as-color-accent: #1e3969;
--as-color-accent-strong:
    hsl(from var(--as-color-accent) h s calc(l - var(--as-color-lightness-factor)));
--as-color-accent-weak:
    hsl(from var(--as-color-accent) h s calc(l + var(--as-color-lightness-factor)));
```

This uses **relative colour syntax**: `hsl(from <colour> h s l)` takes an existing colour, splits it into hue, saturation and lightness channels, and lets you compute new ones. Here "strong" is the same hue and saturation with lightness reduced by 10 points, and "weak" is the same with lightness raised by 10. Relative colour syntax is supported in current versions of all major browsers (it reached them in 2023-2024), but check your own support matrix before relying on it.

The consequences are large:

- **One knob changes the whole system's contrast.** Set `--as-color-lightness-factor` to `15` and every strong/weak pair across accent, text, button, nav, warning, error, success and neutral spreads further apart.
- **Re-theming is a few lines.** Change `--as-color-accent` and its strong and weak variants follow automatically. So do the button backgrounds, since `--as-color-background-button` is just `var(--as-color-accent)`.
- **Variants can't drift.** A hand-picked palette slowly develops inconsistencies as different people add "just one more shade". A derived palette can't.

A second derived token shows the technique's flexibility:

```css
--as-color-text-neutral:
    hsl(from var(--as-color-text) h 0 calc(l + 5 * var(--as-color-lightness-factor)));
```

Saturation is forced to `0` and lightness is raised by 50, so this yields a grey derived from the text colour. The overlay uses the same syntax to set transparency without redefining the colour:

```css
--as-color-overlay: rgb(from #000000 r g b / .5);
```

### Where derivation stops being enough

Be honest with readers about the limits. A fixed lightness shift is simple, but it does not guarantee **contrast**. Making a colour 10 points lighter might drop it below the readable threshold against its background, and a colour that is already very light or very dark has little room to move. The strong and weak variants of `--as-color-status-neutral` (`#cccccc`) have exactly this problem, since a light grey has nowhere to go but near-white.

This is where the design system's own **contrast checker component** earns its place: derived colours are only safe if you verify them. Treat the derivation as a way to *generate* candidates and the checker as a way to *approve* them.

**[AUTHOR NOTE: Do you have a story about a contrast failure caught by the checker? This would be a strong sidebar.]**

---

## The scales

Each non-colour category is a **scale**: a short, ordered set of named steps. The skill is choosing steps that are far enough apart to be distinguishable and few enough to remember.

### Space and size

```css
/* Space: gaps and padding */
--as-space-xxs: .0625rem;   /*  1px */
--as-space-xs:  .25rem;     /*  4px */
--as-space-s:   .5rem;      /*  8px */
--as-space-m:   1rem;       /* 16px */
--as-space-l:   1.5rem;     /* 24px */
--as-space-xl:  2.25rem;    /* 36px */
--as-space-xxl: 3.5rem;     /* 56px */
```

Read the pixel column: 4, 8, 16, 24, 36, 56. Early steps double, then growth slows towards roughly 1.5x. That's a sensible shape: small gaps need fine control, large gaps need big jumps, and there is no wasteful 28px between 24 and 36.

The system has a separate **size** scale (`1px` up to `6rem`) for dimensions such as icon boxes and control heights. Keeping *space* and *size* apart is a good call, because "how big is it" and "how far apart are things" change for different reasons. The risk is overlap: both scales contain `.25rem`, `1rem` and `1.5rem`, so a developer has to choose by meaning rather than by value. Reviewing code for this mistake is a recurring job.

The usage numbers show which scale does the real work. `--as-space-s` is referenced 77 times and `--as-space-m` 67 times, the two most-used tokens in the whole system. The middle of the scale carries the load, which is exactly what a healthy scale looks like.

### Type

```css
--as-font-size-xxxl: 2.25rem;   /* 36px */
--as-font-size-xxl:  1.5rem;    /* 24px */
--as-font-size-xl:   1.25rem;   /* 20px */
--as-font-size-l:    1rem;      /* 16px */
--as-font-size-m:    .875rem;   /* 14px */
--as-font-size-s:    .75rem;    /* 12px */
--as-font-size-xs:   .6875rem;  /* 11px */
```

The root stylesheet maps these onto headings, so `h1` is `xxxl` and `h6` is `s`. The `body` font size comes from `--as-base` (16px), and the smallest step on the scale is 11px.

Line height is a separate scale of purpose-named tokens: `tight` (1.15), `heading` (1.2), `caption` (1.3), `form` (1.25) and the default 1.5. Naming line heights by *use* instead of by size is a nice touch. You choose "heading" or "form" instead of agonising over a number.

### Radius

```css
--as-border-radius-s:      .1875em;
--as-border-radius:        .3125em;   /* default */
--as-border-radius-m:      .5em;
--as-border-radius-l:      1em;
--as-border-radius-pill:   999px;
--as-border-radius-circle: 50%;
```

One detail deserves a note: radius is defined in **`em`**, while space and size use `rem`. An `em` is relative to the element's own font size, so a button with larger text gets proportionally rounder corners automatically. That's a deliberate-looking choice that keeps shapes visually consistent as components scale. The trade-off is that the same token produces different pixel values in different places, which can surprise someone expecting `rem` consistency.

### Time

```css
--as-time-xs: .125s;   --as-time-s: .25s;   --as-time-m: .5s;
--as-time:    1s;      --as-time-l: 2s;     --as-time-xl: 5s;

--as-timing-function-1: ease-in-out;
```

Motion belongs in a token system too. Durations are consistent across the system, and the 125ms step is by far the favourite, referenced 32 times for hover and focus transitions. There's one easing curve, which keeps the motion feel uniform, though it also means every transition feels the same whether it's a hover or a drawer sliding in. We'll revisit motion properly in the accessibility chapter.

### Z-index

```css
--as-index-masked:     100;   --as-index-mask:    200;
--as-index-sticky:     300;   --as-index-navigation: 400;
--as-index-top-bar:    500;   --as-index-overlay: 600;
--as-index-spinner:    700;   --as-index-popout:  800;
--as-index-toast:      900;   --as-index-modal:  1000;
```

Z-index is the category where tokens help most, because the values mean nothing individually. Only the *order* matters, and an order is easy to get wrong across 25 components written at different times. Naming the layers (a toast sits above a popout, a modal sits above everything) turns "pick a big number" into "pick a layer". The spacing of 100 leaves room to insert a layer later without renumbering.

---

## Icons as tokens

The oddest tokens in the system are also the most numerous. Here is how an icon is declared (shortened):

```css
--as-icon-phone: url(data:image/svg+xml;base64,PHN2ZyB4bWxucz0i…);
```

Each of the 70 icons is an SVG, base64-encoded, stored in a custom property. The `as-icon` component then renders it using CSS masking:

```css
mask-image: var(--icon, var(--as-icon-arrow-right));
mask-repeat: no-repeat;
mask-size: contain;
mask-position: center;
```

Used as a mask, the SVG acts as a stencil, and the visible colour comes from the element's own `background-color`. So **icons automatically take any colour** (including the derived variants from earlier) with no inline SVG and no extra requests. The system also ships a component for the encoding step itself, the SVG-to-Base64 tool.

The costs are the ones you'd expect:

- **Every icon ships with the stylesheet**, used or not. The source declares 79 icon custom properties (the docs list 70), which come to about 73 kB, roughly a third of the unminified component CSS, and about 23 kB of the 41 kB gzipped CSS bundle when compressed on their own. Base64 is also about a third larger than the raw SVG.
- **They can't be cached or loaded separately** from the CSS that contains them.
- **Masks are single-colour.** A multi-colour icon needs a different approach.

For a system with a few dozen simple glyphs that's a fair trade for zero requests and free theming. At several hundred icons it would stop being fair. Knowing where that line sits is part of the design.

---

## An honest audit

A token system is only as good as its adoption. The numbers below come from a script run against the repository, counting how many declared tokens are actually referenced by component CSS. The script is included at the end of this chapter so you can run it on your own system.

**Declared vs used (non-icon tokens)**

| Category | Declared | Used |
|---|---|---|
| Colour | 35 | 32 |
| Space | 10 | 8 |
| Size | 13 | 12 |
| Font | 13 | 12 |
| Z-index | 12 | 7 |
| Time | 6 | **2** |
| Ratio | 3 | **1** |

Overall, **21 of about 110 non-icon tokens are not referenced by any component stylesheet.** Remember the caveat: a token unused internally may well be used by consumers, so "unused" means "unproven", not "dead".

The most striking row is time. Six durations are declared and only two appear in component CSS (`--as-time-xs` and `--as-time-s`). Meanwhile the same CSS contains **29 hard-coded durations** such as `.3s` and `400ms`.

### Hard-coded values

Searching the component stylesheets turns up:

- **107 raw `px` values** (many legitimate, such as 1px borders)
- **27 hard-coded hex colours**
- **29 hard-coded durations**
- Several raw z-index values, including `1000` in two components, written as a local `--z-index: 1000` instead of `var(--as-index-modal)`. They happen to agree today and will silently drift apart the day someone changes the modal layer.

Not all of those are mistakes, and a chapter on tokens should say so. A 1px border is not a design decision. A one-off animation timing may genuinely be unique. But every raw value is a place where the system's intent and its implementation can diverge.

### Where intent and code disagree

Three small findings make a useful lesson about comments:

1. **`--as-base: 16px` carries the note "adjust THIS variable ONLY".** But space, size and font tokens are defined in `rem`, which follows the browser's root font size and not this variable. Changing `--as-base` does change the `body` font size and the max-width calculation, but none of the `rem`-based space, size or font-size tokens. The comment promises a global scaling control that the code only partly delivers.
2. **`--as-color-overlay`** is commented as "text-strong with 50% opacity" but is actually black at 50%.
3. **`--as-color-status-success`** has a comment that reads "status-error", a copy-paste leftover.

None of these causes a bug. All three show how **comments rot while code keeps running**. The fix is structural. Where possible, let the system document itself. This system's docs site already reads `computedValue` for each token, which is the right instinct, and the next step is to generate documentation from the declarations instead of writing comments beside them.

### The documentation gap

Roughly 15 declared tokens aren't on the documentation site, and the ones that are documented carry placeholder descriptions such as "This is Phone Icon token." The pattern is common: tokens get added in CSS faster than the docs catch up. A cheap guard is a build-time check that fails if a declared token has no documentation entry. Chapter 7 shows how to wire that into the Eleventy build.

**[AUTHOR NOTE: This section is the most useful in the chapter. If you're comfortable publishing your own audit numbers, say so openly. It makes the book more credible, not less. Consider fixing a few of these before publication and showing the diff.]**

---

## Try it: audit your own tokens

Save this as `token_audit.py`:

```python
import re, glob, sys
from collections import Counter

TOKENS_FILE = sys.argv[1]            # the file that declares your tokens
CSS_GLOB    = sys.argv[2]            # your component CSS, e.g. "css/components/*.css"
PREFIX      = sys.argv[3] if len(sys.argv) > 3 else "--as-"

declared = set(re.findall(rf"({re.escape(PREFIX)}[a-z0-9-]+)\s*:", open(TOKENS_FILE).read()))
css = "".join(open(f).read() for f in glob.glob(CSS_GLOB, recursive=True) if f != TOKENS_FILE)
used = Counter(re.findall(rf"var\(({re.escape(PREFIX)}[a-z0-9-]+)", css))

unused = sorted(t for t in declared if used[t] == 0)
print(f"declared: {len(declared)}  unused: {len(unused)}")
print(f"hard-coded hex colors: {len(re.findall(r'#[0-9a-fA-F]{3,8}\b', css))}")
print(f"hard-coded px values:  {len(re.findall(r'\b\d+px\b', css))}")
print(f"hard-coded durations:  {len(re.findall(r'\b\d*\.?\d+m?s\b', css))}")
print("unused tokens:", *unused, sep="\n  ")
```

Run it:

```bash
python3 token_audit.py css/tokens.css "css/components/*.css" --as-
```

**Exercises**

1. Run the audit on your own project. Which category has the worst gap between declared and used?
2. Pick one hard-coded duration or colour and replace it with a token. Did it feel obvious, or did you need a new token? Both answers are informative.
3. In a browser, set `--as-color-accent` to a different colour and `--as-color-lightness-factor` to `20` in dev tools. Watch buttons, nav and status colours respond. Then run the contrast checker on the result.

---

## Chapter summary

- A token is **a named decision**. The AS system uses plain CSS custom properties, with no build pipeline needed.
- The system has **three naming layers**: a raw palette, semantic tokens (`--as-{category}-{role}-{variant}`), and component-local variables.
- **Colour variants are derived** with relative colour syntax from one accent and one lightness factor, which makes re-theming cheap. Derived colours still need **contrast verification**.
- Every non-colour category is a **short scale**. Space and size are separate, radius uses `em` so it scales with the component, and z-index is named by layer.
- **Icons are base64 SVG tokens** rendered through CSS masks, which gives free theming at the cost of shipping all of them with the stylesheet.
- The audit shows a good system with typical gaps: **21 unused tokens, 29 hard-coded durations, and comments that disagree with code.** Auditing tokens regularly, and publishing the results, is part of maintaining a system.

**Next:** Chapter 3 moves up a level to the small components: toast, tab, gauge, drawer and popout, each under 100 lines. We'll build them in an afternoon and fix the drawer's re-render bug from Chapter 1 along the way.
