# Chapter 4: Conventions: Making 25 Components Feel Like One System

> **Draft 1.** Statistics come from scripts run against the AS Design System repository and its documentation data files. The base class in this chapter was written for this book and tested in jsdom against a refactored drawer. Items marked **[AUTHOR NOTE]** are places for your own story.

---

## What makes a set of components a system

Take any two components from a library written over several months by one person. Do they take configuration the same way? Do they announce changes the same way? Can you guess the name of an attribute you haven't looked up?

If yes, you have a system. If no, you have a folder of components.

Chapter 3 looked at components one at a time. This chapter looks at what runs *between* them: the conventions that make `<as-drawer position="right">` and `<as-carousel autoplay>` feel like the work of one team. The AS Design System is strong on some of these and weaker on others, and the difference is a useful lesson in what to automate.

---

## The public API is a contract

Start with a question that sounds dull and turns out to govern everything: **what, exactly, can a consumer depend on?**

For these components there are four layers of surface, and only three should be promised:

| Surface | Example | Promise it? |
|---|---|---|
| **Attributes** | `position="right"` | Yes, this is the input contract |
| **Events** | `as-drawer:after-open` and its `detail` | Yes, this is the output contract |
| **Tokens** | `--as-color-accent` | Yes, this is the theming contract |
| **Internal DOM** | `.as-drawer`, `[opendrawer]` | **No**, free to change |

The first three are what you document and version. The fourth is what you refuse to document, so that you stay free to change it. Once someone writes a stylesheet that targets `.as-drawer .inner`, you have promised that structure, whether you meant to or not.

A practical rule follows: **semantic versioning applies to the first three layers.** Renaming an attribute or event is a breaking change. Adding one is a minor change. Changing internal markup is a patch, *provided you never told anyone about it*.

---

## Convention 1: Attributes in, always kebab-case

Across the documentation data, the system lists **105 properties**, and all of them are lowercase and hyphenated: `button-text`, `icon-name`, `digit-color`, `transition-time`. Not one is camelCase. Each is documented with its component, a description, a type (`propertyType`) and an optional flag.

That regularity is the single biggest reason the system is guessable. Hyphenated lowercase is also the only form that behaves predictably in HTML, which is case-insensitive.

The distribution is informative too. A few components carry most of the configuration:

| Component | Documented properties |
|---|---|
| Graph | 11 |
| Search menu | 11 |
| Gauge | 9 |
| Icon | 8 |
| Form validation | 7 |
| Class toggle | 7 |

The smallest components have one or two. The shape is healthy: simple things are simple, and complexity is opt-in.

### Where the convention bends

There is one fault line. Most attributes are plain (`position`, `size`, `delay`), but a handful of components use a `data-` prefix instead:

- `as-graph` reads `data-data`
- `as-table-actions` reads `data-table`
- `as-char-counter` reads `data-input`
- `as-select-multiple` reads `data-value` and `data-placeholder`

There's a defensible rule behind it. The `data-` attributes mostly point at **other things**: another element's selector (`data-input`, `data-table`) or a payload (`data-data`). Plain attributes configure the component itself. If that is the rule, it's worth stating, because right now a reader has to infer it. A component whose documentation page lists `data-input` next to `button-text` looks inconsistent even when it isn't.

**[AUTHOR NOTE: Was the `data-` split deliberate? If so, say so. Readers will trust a convention more once they know it was chosen rather than accidental.]**

### A note on identifiers

Nineteen of the component files call `crypto.randomUUID()` to give elements an ID when the author didn't supply one:

```js
this.drawerId = this.getAttribute("id") || crypto.randomUUID()
```

It's a good habit. Anything that needs to cross-reference elements (a popover and its button, a tab and its panel) needs a stable unique ID. One caution: `crypto.randomUUID()` is only available in **secure contexts**, meaning HTTPS or `localhost`. Open a page over plain `http://` on a LAN address and every one of those components throws on connect. It's harmless in production on HTTPS and a confusing failure on a phone testing against a dev server. A one-line fallback (`crypto.randomUUID?.() ?? Math.random().toString(36).slice(2)`) removes the trap.

---

## Convention 2: Events out, named like a sentence

The documentation lists **51 event entries covering 41 distinct events** (a few are listed more than once, with different example payloads), and every one follows a single pattern:

```
as-{component}:{what-happened}
```

I checked every entry against that pattern, and there were no exceptions. That is an impressive result for a hand-maintained system, and it is the reason a consumer can write a listener from memory.

The vocabulary of verbs is small and reusable:

| Verb | Doc entries | Meaning |
|---|---|---|
| `created` | 12 | The component finished rendering |
| `selected` | 4 | The user chose something |
| `toggle` | 4 | Open/closed state changed |
| `download` | 4 | A file or export was produced |
| `show` / `hide` | 3 each | A visibility change |
| `sorted` / `filtered` / `search` | 2 each | A data operation completed |

And one pair of families worth copying everywhere. The drawer emits `before-open`, `after-open`, `before-close` and `after-close`. The `before-` event fires when an action *starts* and `after-` when it *finishes*, which lets outside code hook into the animation without the drawer knowing anything about it.

### The payload convention

Look at what's inside the events. Across the `broadcastEvent` calls in the code, the most common key in the `detail` object is `id`, which appears about 40 times. The next is `action` (15), then `fieldid` (7) and `state` (6).

So by convention **every event says which instance it came from.** That matters when a page holds six drawers or three tables and a single listener has to tell them apart:

```js
document.addEventListener('as-drawer:after-open', e => {
    if (e.detail.id === 'filters') trackOpen()
})
```

### Events as glue between components

Here is the most interesting use of events in the codebase. `as-table-actions` needs to know when a popout inside it opens and closes. It doesn't import the popout or call a method on it. It **listens for the popout's events on `document`**:

```js
document.addEventListener('as-popout:created', e => { ... })
document.addEventListener('as-popout:toggle', e =>
    this.broadcastEvent('as-table-actions:popover', { id: this.tableActionsId, state: e.detail.state }))
```

That's loose coupling in its simplest form. The table-actions component depends on the popout's *public event contract*, not on its code, and re-broadcasts the state as its own event. It's the same mechanism a consumer would use, which is a sign that the contract is real.

It also depends on **bubbling**, and that's where the convention leaks.

### Where the convention bends: bubbling

Fifteen files define their own `broadcastEvent` helper. Eleven produce bubbling events. Four don't:

- `as-char-counter`, `as-class-toggle` and `as-table-actions` leave `bubbles` out of the helper altogether.
- `as-select` has a helper that *defaults* to bubbling (`bubbles = true`), but calls it with `false` on every event it fires (six calls).

A `CustomEvent` doesn't bubble unless you ask it to. So for those four components, this works:

```js
counter.addEventListener('as-char-counter:count', handler)     // on the element itself
```

but this silently never fires:

```js
document.addEventListener('as-char-counter:count', handler)    // never receives it
```

Everywhere else in the system, `document`-level listening works, so a developer reasonably expects it to work here too. It's a quiet inconsistency, and the documentation doesn't mention it. Nothing in the code is wrong in isolation. The cost of the convention is paid only by someone who trusts it.

The cause is the next topic.

---

## Convention 3: The copy-paste helper

Here is the helper that 15 files carry:

```js
isEmpty(obj) {
    for (const prop in obj) {
        if (Object.hasOwn(obj, prop)) return false
    }
    return true
}

broadcastEvent(name, detail = {}) {
    const cEvent = this.isEmpty(detail)
        ? new CustomEvent(name, { bubbles: true })
        : new CustomEvent(name, { detail, bubbles: true })
    this.dispatchEvent(cEvent)
}
```

It's 15 near-identical copies, and the copies have started to drift. Three dropped `bubbles`, and one more overrides it to `false`. One implements `isEmpty` slightly differently. And debugging `console.log` calls remain in twelve of the component files, including one that logs every event it fires. Nobody planned any of this. It's what *always* happens to copied code: each copy is edited for the case in front of you, and the family slowly diverges.

### Why the copies exist

Chapter 1 explained the principle: one file per component, no imports, so that each file can be copied alone into a project. It's a real benefit and the duplication is its price.

But look at how the system is actually *delivered*. `eleventy.config.js` already runs **esbuild** over all the component files and produces a single `components.js`:

```js
const jsImports = jsFiles.map(f => `import "./${f}"`).join("\n")
```

Consumers load that bundle. Esbuild resolves `import` statements natively, so a shared module would be included **once**, in the right order, with no extra requests. The "copy one file" argument applies only to someone who copies a single component out of the repository by hand. If that person matters to you, keep the duplication. If your consumers load the bundle, a shared base class costs them nothing.

**[AUTHOR NOTE: Which consumer do you actually have? If everyone uses the bundle, say that the duplication is historical. If you want to support copy-one-file, say that too. This is the decision the whole chapter turns on.]**

---

## Designing the shared base

If you decide to share, here is a base class that encodes every convention in this chapter. I wrote it for this book and tested it against a refactored drawer:

```js
// as-element.js  (note: no "-component" suffix, so the build won't treat it as an entry point)
export class ASElement extends HTMLElement {
    static attrs = {}                       // { 'attribute-name': defaultValue }
    #rendered = false
    #abort = null

    connectedCallback() {
        if (!this.#rendered) {              // once per element, never on re-attach
            this.id ||= `${this.localName}-${crypto.randomUUID?.() ?? Math.random().toString(36).slice(2)}`
            this.settings = Object.fromEntries(
                Object.entries(this.constructor.attrs)
                    .map(([name, fallback]) => [name, this.getAttribute(name) ?? fallback]))
            this.render()
            this.#rendered = true
            this.emit('created')
        }
        this.#abort = new AbortController() // on every attach: (re)bind listeners
        this.bind(this.#abort.signal)
    }

    disconnectedCallback() { this.#abort?.abort() }

    emit(name, detail = {}) {               // always bubbles, always carries the id
        this.dispatchEvent(new CustomEvent(`${this.localName}:${name}`, {
            bubbles: true, composed: true, detail: { id: this.id, ...detail }
        }))
    }

    render() {}                             // build the DOM once
    bind(signal) {}                         // add listeners, passing { signal }
}
```

Read what this one class settles for every component that extends it:

- **Idempotency.** `render()` runs once per element. The drawer's duplicate-on-move bug can't happen.
- **Cleanup.** Listeners are added in `bind(signal)`, and removed automatically on disconnect. They're re-added if the element is re-attached.
- **Identity.** Every element gets an ID, with a fallback for non-secure contexts.
- **Configuration.** A single `static attrs` map declares every attribute and its default, which doubles as machine-readable documentation.
- **Events.** `emit('created')` produces `as-drawer:created` with `bubbles: true` and an `id` in `detail`, every time, for every component.

Two design choices deserve explanation.

**Why `render()` and `bind()` are separate.** The obvious design is to put everything in `init()` behind a `ready` flag, which is what the current components do. But that leaves a gap: if an element is removed and re-attached, its DOM survives but its listeners (cleaned up on disconnect) are gone. Splitting *build once* from *listen on every attach* closes it.

**Why `emit()` namespaces automatically.** It uses `this.localName` (`as-drawer`), so the event name is derived from the tag. The convention (`as-{component}:{verb}`) can't be broken by a typo, because nobody types the prefix.

### The drawer, rewritten

```js
import { ASElement } from './as-element.js'

class ASDrawer extends ASElement {
    static attrs = { position: 'bottom', 'button-text': 'Open drawer' }

    render() {
        const content = [...this.childNodes]
        this.button = Object.assign(document.createElement('button'), {
            textContent: this.settings['button-text'], className: 'btn'
        })
        this.panel = document.createElement('div')
        this.panel.className = `as-drawer ${this.settings.position}`
        this.panel.setAttribute('role', 'dialog')
        this.panel.hidden = true
        this.panel.append(...content)
        this.replaceChildren(this.button, this.panel)
    }

    bind(signal) {
        this.button.addEventListener('click', () => this.open(), { signal })
    }

    open() {
        this.emit('before-open')
        this.panel.hidden = false
        this.emit('after-open')
    }
}
customElements.define('as-drawer', ASDrawer)
```

This is a trimmed version, without the overlay and animation timing, to show the shape. I tested it in jsdom:

```
after two moves:  buttons 1 | panels 1 | content 1
open event seen at document: 1 (id starts with "as-drawer-")
after remove, click no longer opens: still 1
button text rendered as text, not HTML
```

Moving the element twice doesn't duplicate anything, the event bubbles to `document` with an ID, the listener is gone after removal, and the button label is set with `textContent`, so a hostile attribute value can't inject markup.

### The trade-offs, honestly

A base class isn't free:

- **It's an import.** Single-file copying is gone. Each component now depends on `as-element.js`.
- **It's a coupling point.** A bug in the base affects all 25 components. That's the other side of "fix it once".
- **It's opinionated.** The `static attrs` map reads every attribute as a string, so numbers and booleans need parsing. You'd probably add a small type layer.
- **It needs a migration.** Moving 25 components takes time, and you can do it gradually. A component that doesn't extend the base still works beside the ones that do.

**The decision rule:** if you ship a bundle, share the base. If you ship individual files to people who copy them, keep the duplication and write a lint rule that checks the copies match.

---

## Enforce conventions with tools, not memory

The system's naming conventions are impressive because they were held by one careful person. Conventions held by memory don't survive a second contributor. The gaps found above (bubbling, `data-` attributes, stray `console.log`) are all the kind of thing a script catches in a second.

Here's a small check that fails the build if a component breaks the event-naming or bubbling rules:

```js
// check-conventions.mjs
import fs from 'fs'
const dir = 'src/assets/js/components/'
let failures = 0

for (const file of fs.readdirSync(dir).filter(f => f.endsWith('-component.js'))) {
    const src = fs.readFileSync(dir + file, 'utf8')

    // 1. Every event name must be as-{component}:{verb}
    for (const [, name] of src.matchAll(/broadcastEvent\('([^']+)'/g)) {
        if (!/^as-[a-z0-9-]+:[a-z0-9-]+$/.test(name)) {
            console.error(`${file}: bad event name "${name}"`); failures++
        }
    }
    // 2. broadcastEvent must bubble, and nobody may switch that off per call
    if (src.includes('broadcastEvent(name') && !src.includes('bubbles: true') && !src.includes('bubbles = true')) {
        console.error(`${file}: broadcastEvent does not bubble`); failures++
    }
    if (/broadcastEvent\([^)]*,\s*false\)/.test(src)) {
        console.error(`${file}: broadcastEvent called with bubbles=false`); failures++
    }
    // 3. No leftover console.log
    if (/console\.log\(/.test(src)) {
        console.error(`${file}: console.log left in`); failures++
    }
}
process.exit(failures ? 1 : 0)
```

Wire it into `npm test` or the Eleventy build, and the non-bubbling components fail immediately.

The same idea works for documentation. The docs site already stores events and properties as JSON. A second check can compare that data against the code and fail on drift. That is worth doing: the properties data lists **three properties for a "Pagination" component, but no pagination component file exists**, and the event docs and the code have drifted too: two documented events (the date picker's `open` and `closed`) don't appear as literal names in the source, while seven events the code emits (carousel `play` and `pause`, `as-graph:drawcomplete`, `as-svg-to-base:generated`, two from table sort, and `as-show-hide-password:error`) aren't documented. Small mismatches like these accumulate unless something compares the two.

---

## Try it

1. Run the convention checker on the repository. How many files fail each rule?
2. Copy `as-element.js` and the new drawer into a scratch project. Add a `static attrs` entry for `transition-time`, and parse it as a number in `render()`.
3. Convert `as-tab` to extend `ASElement`. What disappears from the file?
4. Write the **consumer-side** test: a page with three drawers and one `document` listener that logs which one opened. Does the `id` in the payload tell them apart?

---

## Chapter summary

- A system is what's **between** components. Decide what is the public contract (attributes, events, tokens) and what is private (internal DOM).
- The AS system is consistent where it matters: **105 kebab-case attributes** and **41 distinct documented events that all follow `as-{component}:{verb}`**, with `id` in the payload by convention.
- It bends in three places: **`data-` vs plain attributes**, **four components whose events don't bubble**, and **fifteen drifting copies of the same helper**.
- Events are also the **glue between components**. `as-table-actions` listens to `as-popout` on `document`, which only works because the popout bubbles.
- Because the build already bundles the files, a **shared `ASElement` base class** can encode the conventions (render once, bind on every attach, abort on disconnect, namespaced bubbling events) at no cost to bundle users.
- **Enforce conventions in the build**, not in people's heads: a 20-line script catches what careful reading misses.

**Next:** Chapter 5 tackles the complex components: the select family, the date picker, sortable tables, and the command and search menus, where conventions meet real interaction design and the hard parts are keyboard handling and state.
