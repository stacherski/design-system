# Chapter 1: Why Custom Elements, No Framework

> **Draft 1.** Facts and code come from the AS Design System repository. Items marked **[AUTHOR NOTE]** are places for your own story or opinion.

---

## The question behind every design system

Before you write a single token or component, a design system forces one decision that every later decision depends on: **what is this thing built on?**

Most teams answer with their current framework. They build a React component library, or a Vue one, and for a while it works. Then a second team arrives on a different stack. Or a marketing site needs the same button, and the marketing site is a CMS template. Or the framework releases a major version and the library has to follow.

The AS Design System answers differently. It is built on the platform itself: HTML, CSS and JavaScript custom elements. There is no framework, no runtime dependency, and no compile step that the *consumer* has to run.

This chapter explains what that means in practice, why it was chosen, and, just as important, what it costs. Every later chapter builds on the decisions made here.

**[AUTHOR NOTE: One paragraph on the real reason. Was it a CMS constraint, a previous framework migration, a team on mixed stacks? This is the hook that makes the chapter personal.]**

---

## What "framework-agnostic" actually means

"Framework-agnostic" is an easy phrase to say and a hard one to deliver, so let's be precise about it. In this system it means three concrete things:

1. **A component is an HTML tag.** You use `<as-drawer>` the same way you use `<details>` or `<video>`. Nothing needs to be imported into a component tree.
2. **Configuration is attributes.** `<as-drawer position="right" button-text="Filters">`. Any system that can output HTML can configure it, including a CMS template, a server-rendered page or a React component.
3. **Output is DOM events.** When something happens, the component fires a `CustomEvent`. Any code that can call `addEventListener` can respond.

It does **not** mean the components are magically native to every framework. React, Vue and Svelte can all render a custom element, but each has its own quirks around passing complex props and listening to events. Agnostic means *compatible*, not *frictionless*. We'll come back to this in the trade-offs section.

---

## Anatomy of an AS component

The best way to understand the system is to read the smallest component in it. Here is `as-tab`, in full, with only comments added:

```js
document.addEventListener('DOMContentLoaded', () => {
    // Guard: don't register twice
    if (window.customElements.get('as-tab') === undefined) {
        class ASTab extends HTMLElement {

            constructor() {
                super()
                this.ready = false          // Guard: don't initialise twice
            }

            connectedCallback() {
                // Read configuration from attributes
                this.tabId = this.getAttribute('id') || crypto.randomUUID()
                this.iconName = this.hasAttribute('icon-name')
                    ? this.getAttribute('icon-name') : ''

                if (this.ready) return
                this.init()
            }

            init() {
                if (this.iconName.length > 0) {
                    const icon = document.createElement('as-icon')
                    icon.setAttribute('name', this.iconName)
                    this.prepend(icon)       // Compose other components
                }
                this.ready = true
            }
        }

        window.customElements.define("as-tab", ASTab)
    }
})
```

Thirty-four lines. Everything the system relies on is already visible here. Let's pull it apart.

### 1. The registration guard

```js
if (window.customElements.get('as-tab') === undefined) { ... }
```

Calling `customElements.define()` twice with the same name throws an error. If a page accidentally loads the script twice, say once from the bundle and once from a CMS module, an unguarded component would break the page. The guard makes loading **idempotent**: the second load quietly does nothing.

This is a small habit with a large payoff. In a CMS environment, where you don't fully control which scripts end up on a page, it prevents an entire class of bugs.

### 2. `connectedCallback` as the entry point

A custom element has a lifecycle. The browser calls `connectedCallback()` when the element is attached to the document. In AS components, this is where configuration is read and the component starts working.

Notice what it does *not* use: a constructor for setup. The specification restricts what a constructor may do (an element may not have attributes or children yet when it runs), so the safe place to read attributes is `connectedCallback`.

### 3. Attributes as the public API

```js
this.iconName = this.getAttribute('icon-name')
```

Every option is an attribute, written in kebab-case. The documentation site records these as "properties". There are 105 documented across the system. Attributes have a useful property: they are visible in the HTML, inspectable in dev tools, and writable from any language that can produce markup.

### 4. Composition by tag name

`as-tab` creates an `as-icon` and prepends it. Components use each other the same way a page author would, by creating elements. There's no import graph and no dependency injection. If `as-icon` is on the page, it works.

### 5. The `ready` flag

`connectedCallback` can run more than once. Moving an element in the DOM triggers a disconnect and reconnect, and each reconnect calls `connectedCallback` again. The `ready` flag stops `as-tab` from adding its icon a second time. Hold on to this one, because not every component in the system has it, and we'll see what happens when one doesn't.

---

## Four decisions that define the system

The anatomy above reflects four deliberate decisions. Each is a trade, so let's name what was chosen and what was given up.

### Decision 1: Custom elements instead of a framework

**Chosen:** the browser's own component model.
**Given up:** declarative rendering, reactive state, a rich ecosystem of tooling.

A custom element is the least you can ask of the browser to get a reusable, named, self-initialising component. The system leans on it and nothing more. The result is zero runtime dependencies: the repository's own `package.json` lists Eleventy and esbuild, and both are build tools for the *documentation site*, not code a consumer ever loads.

### Decision 2: Light DOM instead of Shadow DOM

This is the least obvious decision and probably the most consequential. Search the repository for `attachShadow` and you will find **zero results**. Every component renders into the regular ("light") DOM.

**Chosen:** components that are styled by the same CSS as the rest of the page.
**Given up:** style encapsulation.

Shadow DOM gives a component a private DOM tree that outside CSS cannot reach. That is excellent for widgets dropped into pages you don't control. It is awkward for a design system whose whole purpose is *shared* visual language. With shadow DOM, every token has to be deliberately passed through, and every theme change has to cross a boundary.

With light DOM:

- Global tokens such as `--as-color-text` and `--as-space-s` reach every component without extra work.
- A page can restyle a component with ordinary CSS.
- Dev tools show the real structure.
- Form controls inside a component participate in the surrounding `<form>` naturally. Shadow DOM is notoriously awkward here.

The cost is real, though. Outside CSS can *accidentally* break a component, and a component's internal class names (`.as-drawer`, `.as-overlay`) share a namespace with everything else. The system handles this with a prefix convention, which we will look at in Chapter 4. It is a convention, not a guarantee.

### Decision 3: Attributes in, events out

**Chosen:** a deliberately narrow public surface.
**Given up:** rich, typed APIs.

Attributes are strings. That limits what you can pass in, so a list of options or a callback can't be an attribute. Where the system needs richer input (the command menu is the main case), it accepts a JavaScript options object instead. For everything else, strings are enough, and the benefit is that the component can be configured from plain markup.

For output, components use **namespaced custom events**, which bubble in most of them (Chapter 4 covers the four exceptions). The drawer is a good illustration. It fires `as-drawer:created`, `as-drawer:before-open`, `as-drawer:after-open`, `as-drawer:before-close` and `as-drawer:after-close`. The documentation lists 51 event entries covering 41 distinct events.

```js
document.addEventListener('as-drawer:after-open', e => {
    console.log('Opened:', e.detail.id, e.detail.position)
})
```

Because the drawer's events bubble, one listener on `document` can observe every drawer on the page. The `before-` and `after-` pairs let outside code hook into the animation without the component knowing anything about that code.

### Decision 4: A thin build step, for the author only

The components live as one JS file and one CSS file each. At build time, `eleventy.config.js` generates a list of imports, one per component file, and has esbuild bundle them into a single `components.js` and a single `components.css`. The page then loads two files:

```html
<link rel="stylesheet" href="/assets/css/components.css"/>
<script defer src="/assets/js/components.js"></script>
```

Adding a component to the system means dropping two correctly named files into a folder. There's no registry file to edit. The build discovers them by filename (`*-component.js`, `*-component.css`).

This is the philosophy in miniature: the *author* gets a little tooling, and the *consumer* gets plain files.

---

## What it costs: an honest ledger

A chapter that only praised the approach would not be much use to someone deciding whether to copy it. Here is what you pay, using real examples from this codebase.

### Cost 1: Configuration is read once

Most components read their attributes in `connectedCallback` and never look again. Across all the JS, there are only 11 mentions of `observedAttributes`, `attributeChangedCallback` and `disconnectedCallback` combined.

So this works:

```html
<as-drawer position="left"></as-drawer>
```

But this probably doesn't do what you'd expect:

```js
drawer.setAttribute('position', 'right')   // nothing re-renders
```

Framework components re-render when their inputs change. These don't, by design, because that logic costs code. If you need live updates, you must write the observation yourself.

### Cost 2: Re-connection can re-render

Compare the drawer with the tab. The tab has a `ready` flag. The drawer does this in `connectedCallback`:

```js
this.settings.content = this.innerHTML
...
this.render()   // replaces innerHTML with a button + drawer wrapper
```

The drawer captures its own `innerHTML` as "content", then replaces it with a rendered structure that contains that content. If the element is moved in the DOM, `connectedCallback` runs again, and this time the captured "content" includes the structure it generated the first time. The result is a nested duplicate.

It's an easy bug to fix (the `ready` pattern from `as-tab` is the fix), and it's a useful lesson: **every component that renders from its own children needs an idempotency guard.** We'll apply that fix when we reach the small components in Chapter 3.

### Cost 3: Duplicated helpers

Of the 25 files that define a custom element, 15 contain their own copy of the same `broadcastEvent` helper (and often the `isEmpty` function it uses). There is no shared base class.

That is a consequence of the "one file per component, no imports" rule. Each file is fully self-contained and can be dropped into a project alone, which is real value. The price is that a fix to the helper has to be made in fifteen places.

There's a genuine design choice here. A shared `ASElement` base class would remove the duplication but would turn "copy one file" into "copy two files in the right order". Which side you land on depends on who consumes your system. Chapter 4 explores how to make that call.

### Cost 4: Strings into `innerHTML`

The drawer builds its markup with a template literal and assigns it to `innerHTML`, including the `button-text` attribute value:

```js
<button opendrawer class="btn btn__solid_primary">${this.settings.button}</button>
```

Attribute values are written by the page author, so in a trusted codebase this is low risk. In a system where attribute values might come from user input or a CMS field that non-developers edit, it is an injection path. Building the element with `textContent` instead removes the issue at almost no cost. We'll treat this properly in the book's accessibility and hardening chapter.

### Cost 5: Late definition

Every component registers inside a `DOMContentLoaded` handler. Because the script is loaded with `defer`, it executes before that event fires, so this works. But it means the elements aren't defined until the document is fully parsed, so there can be a moment where the tags exist in the markup, un-upgraded and unstyled. Defining components immediately avoids that, at the cost of the parse-order guarantees the current approach gives you.

None of these are fatal. They are the normal price of a system that stays small and readable, and each one becomes a section of a later chapter.

---

## When not to choose this approach

Light-DOM custom elements are a good fit for:

- design systems that must serve **multiple stacks** or **CMS templates**
- internal tools, dashboards and content sites
- teams that value **longevity**: platform features don't get deprecated the way library APIs do
- small teams who want to read and own all the code

They are a weaker fit for:

- applications with **heavy shared state** and complex re-rendering, where a framework earns its weight
- widgets embedded in **third-party pages**, where shadow DOM's isolation is worth its friction
- teams already **fully committed to one framework** with no second consumer in sight

**[AUTHOR NOTE: Add your own boundary. Where would you reach for a framework instead?]**

---

## Try it: write a component the AS way

Here's a small component that follows every convention from this chapter, including the fixes for Costs 1, 2 and 4. It is a status badge:

```js
document.addEventListener('DOMContentLoaded', () => {
    if (window.customElements.get('as-status') !== undefined) return

    class ASStatus extends HTMLElement {
        static observedAttributes = ['label', 'tone']

        connectedCallback() {
            if (this.ready) return            // idempotency guard
            this.ready = true
            this.span = document.createElement('span')
            this.span.className = 'as-status'
            this.append(this.span)
            this.update()
            this.dispatchEvent(new CustomEvent('as-status:created', {
                bubbles: true, detail: { label: this.span.textContent }
            }))
        }

        attributeChangedCallback() {          // live updates
            if (this.ready) this.update()
        }

        update() {
            this.span.textContent = this.getAttribute('label') || ''   // not innerHTML
            this.span.dataset.tone = this.getAttribute('tone') || 'info'
        }
    }

    window.customElements.define('as-status', ASStatus)
})
```

Use it like this:

```html
<as-status label="Published" tone="success"></as-status>
```

**Exercise.** Add a `disconnectedCallback` that fires `as-status:removed`. Then move the element to a different parent with JavaScript and check in the console that the badge is not duplicated. Finally, change `label` with `setAttribute` and confirm the text updates.

---

## Chapter summary

- The system is built on **custom elements in the light DOM**, with **attributes as input** and **bubbling, namespaced events as output**.
- A component is **one JS file plus one CSS file**, found by filename and bundled by a small esbuild step. Consumers load two files.
- Every component starts from the same skeleton: **registration guard, `connectedCallback`, attribute reads, render, event broadcast.**
- The approach trades **reactivity and encapsulation** for **portability and readability**. The costs are real: static config, re-connection bugs, duplicated helpers and unsafe string rendering.
- Each cost has a known fix, and several become chapters of their own.

**Next:** Chapter 2 moves from components to the values beneath them. It covers the 165 design tokens (95 of them non-icon values), how relative color syntax derives "strong" and "weak" variants from a single accent, and why spacing, size and type scales are designed as systems rather than lists.
