# Chapter 9: Auditing Your Own System for Accessibility

> **Draft 1.** Every finding comes from the AS Design System repository. Contrast ratios were computed, automated checks (axe-core) and DOM inspections were run in jsdom, and each proposed fix was applied to the real component file and re-tested. **Limits:** jsdom has no layout engine and no assistive technology, so everything here is code-level evidence, and it must be confirmed with real browsers and screen readers before you publish claims. Items marked **[AUTHOR NOTE]** are places for your own story.

---

## Why this chapter is the one to be brave about

Most design system books claim accessibility. Few show a measured audit of their own system, with the bad numbers included. That is exactly why this chapter is valuable: readers trust a system more when its author demonstrates how to *find* problems, not only that none exist.

The AS Design System has real strengths here and real gaps. The point of the chapter is the method: **four lenses, applied in order, each producing evidence you can re-run.**

1. **Automated checks** that catch what machines can see.
2. **Contrast maths** computed from the design tokens.
3. **Structure**: the roles and relationships assistive technology reads.
4. **Behaviour**: keyboard, focus and motion.

Then a fix kit, and a way to keep the problems from coming back.

---

## The scoreboard

| Area | Finding |
|---|---|
| Automated (axe-core, jsdom) | 3 distinct violations in the components tested |
| Colour contrast | 4 token pairs fail the WCAG AA text minimum |
| Tab group | roles present, but no `tablist`, `tabpanel` or `aria-controls` |
| Drawer | cannot be closed from the keyboard, and focus never moves into it |
| Collapsible panel | the heading is a click-only element |
| Select | the visible input has no label |
| Toast | close button has no accessible name |
| Focus styles | 22 `outline: none` rules, **0** uses of `:focus-visible` |
| Motion | 79 transition and animation declarations, **0** `prefers-reduced-motion` rules |

And there are things the system does well. We'll start there, because it's useful to know what to protect.

---

## What the system already gets right

- **Icons are hidden by default.** `as-icon` sets `aria-hidden` unless you provide a `label`. Decorative icons are silent, and meaningful ones need an explicit name. That is the correct default.
- **Native elements where it counts.** Triggers are real `<button>`s. The command menu uses `<dialog popover>`, the date picker falls back to a native `type="date"` on small screens, and the select keeps a real `<select>` as its source of truth.
- **Form validation announces itself.** The error message region is created with `aria-live="polite"`, so a screen reader hears the text when it appears.
- **The graph offers a data table.** Chart information is available as a table, which is the best available alternative to a picture of data.
- **The carousel has a pause control.** Auto-rotating content needs a way to stop (WCAG 2.2.2), and a Play/Pause button is built in.
- **Tab keys.** The tab group sets `role="tab"` and `aria-selected`, and supports the arrow keys.
- **Language is declared.** The docs layout sets `<html lang="en">`.

A system that does all of this by instinct is one fix pass away from a good result.

---

## Lens 1: Automated checks

[axe-core](https://github.com/dequelabs/axe-core) is the standard rules engine, and it runs in jsdom. I loaded the real component files into a page, let them render, and ran axe with colour-contrast disabled (jsdom has no layout or computed colours, so contrast has its own lens).

```js
const r = await window.axe.run(document, {
  rules: { 'color-contrast': { enabled: false } },
  resultTypes: ['violations']
})
```

The results, across the select, drawer, popout, panel, tab group, show/hide password and icon:

| Rule | Component | Impact |
|---|---|---|
| `label`: form elements must have labels | `as-select` | critical |
| `aria-required-parent`: `role="tab"` needs a `tablist` parent | `as-tab-group` | critical (3 nodes) |
| `aria-dialog-name`: a dialog must have a name | `as-drawer` (when open) | serious |

Three findings from a handful of components is a modest result, and it is not the whole story. Two lessons about automation:

**1. Timing matters.** My first run reported only the select, and missed the tab group entirely. The tab group initialises in a microtask (`Promise.resolve().then(() => this.init())`), so the first scan ran before the roles existed. A scan has to wait for the component to finish rendering. The same applies to your CI tests.

**2. Automation can't see a missing semantic.** axe flagged what is *wrong*. It cannot flag what is *absent*. A `div` with a click handler and no role is invisible to it, because nothing in the markup says it's meant to be a button. The panel heading, the drawer's overlay and the graph's legend are all in that category, and axe found none of them. Automated tools are commonly estimated to catch only a minority of real accessibility problems, and the rest need the other three lenses.

---

## Lens 2: Colour contrast

Chapter 2 showed that the system derives its "strong" and "weak" colour variants by shifting lightness by a fixed amount, and warned that this doesn't guarantee contrast. Here is the proof. I computed the WCAG contrast ratio for the token pairs, using the same HSL maths as the CSS, and compared them with the AA minimums (4.5:1 for normal text, 3:1 for large text and interface components).

| Pair | Ratio | Result |
|---|---|---|
| `text` on `background` | 11.05 | pass |
| `text` on `panel` | 11.84 | pass |
| `text-weak` on `panel` | 7.62 | pass |
| `accent` on `background` | 10.63 | pass |
| white on `accent` (primary button) | 11.39 | pass |
| white on `accent-weak` (button hover) | 8.05 | pass |
| white on `error` | 8.73 | pass |
| white on `success` | 4.64 | pass (just) |
| `text-nav` on `background-nav` | **2.18** | **fail** |
| `text-nav` on `background-nav-strong` (active/focus) | **1.76** | **fail** |
| white on `warning` (warning badge) | **2.93** | **fail** |
| `text-neutral` on `panel` | **2.12** | **fail** |
| `border-panel` on `panel` (as a form border) | **1.27** | fail (needs 3:1) |

The pattern is clear. The core palette is strong, because the main text, buttons, error and success colours all pass comfortably. The failures are concentrated in the **secondary tokens**:

- **The navigation.** The sidebar's hover, focus and active states use `--as-color-text-nav` (a mid teal, `#429EA6`) on a pale teal background. At 2.18:1 it's hard to read, and on the darker "strong" background used for the active item it drops to 1.76:1. This is the site's own navigation.
- **The warning badge.** White on orange is a famously poor pairing at 2.93:1.
- **`text-neutral`.** It's derived by desaturating the text colour and *adding 50 points of lightness*, which lands on a light grey. It is used for placeholders (command menu, search menu) and inactive states, where text must still be readable.
- **Borders.** `--as-color-border-panel` is a pale grey, correct for a decorative divider, but the table filter inputs use it as their only visible border (`--input-border-color`). A form control's boundary needs 3:1.

### Fixes, and a gate

For each failure there's a token-level fix:

- **Nav states:** use the existing dark `--as-color-text-nav-active` (`#153B50`) for hover, focus and active text on those backgrounds. It scores roughly 6.5 to 8.2.
- **Warning badge:** white on `#F56F16` can't be rescued, so use a darker orange for filled badges. As a reference, `#C2410C` scores 5.18 with white text. Keep the bright orange for non-text uses.
- **`text-neutral`:** replace `l + 50` with roughly `l + 24` (a mid grey around `#707070`). For reference, `#757575` scores 4.61 on white but only 4.30 on the `#f7f7f7` page background, so confirm with the gate below.
- **Input borders:** use a darker border token for form controls. A grey around `#949494` gives about 3:1 on white.

Then make the build enforce it. This 40-line script computes ratios for a list of token pairs, understands the lightness-shift maths, and fails when any pair drops below its minimum. I ran it against the real tokens:

```js
// contrast-gate.mjs: fail the build when a token pair drops below its WCAG minimum
const hex = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16) / 255)
const lum = ([r, g, b]) => [r, g, b].map(v => v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4)
                                    .reduce((s, v, i) => s + v * [0.2126, 0.7152, 0.0722][i], 0)
const ratio = (a, b) => { const [hi, lo] = [lum(a), lum(b)].sort((x, y) => y - x); return (hi + 0.05) / (lo + 0.05) }

// hsl(from c h s calc(l ± n)): the same maths the CSS tokens use
function shiftL(h, delta) {
  const [r, g, b] = hex(h), max = Math.max(r, g, b), min = Math.min(r, g, b), l = (max + min) / 2
  const d = max - min, s = d === 0 ? 0 : d / (1 - Math.abs(2 * l - 1))
  let H = d === 0 ? 0 : max === r ? ((g - b) / d) % 6 : max === g ? (b - r) / d + 2 : (r - g) / d + 4
  H = (H * 60 + 360) % 360
  const L = Math.min(1, Math.max(0, l + delta / 100)), C = (1 - Math.abs(2 * L - 1)) * s
  const X = C * (1 - Math.abs((H / 60) % 2 - 1)), m = L - C / 2
  const [R, G, B] = [[C, X, 0], [X, C, 0], [0, C, X], [0, X, C], [X, 0, C], [C, 0, X]][Math.floor(H / 60) % 6]
  return [R + m, G + m, B + m]
}

// hsl(from c h 0 calc(l + n)): a grey with the same lightness shift
const grey = (h, delta) => { const [r, g, b] = hex(h); const L = Math.min(1, (Math.max(r, g, b) + Math.min(r, g, b)) / 2 + delta / 100); return [L, L, L] }

const T = { text: '#153b50', accent: '#1e3969', bg: '#f7f7f7', panel: '#ffffff', white: '#ffffff',
            nav: '#429EA6', navBg: '#C0DCDE', warning: '#F56F16', error: '#9A031E', success: '#008800' }
const pairs = [  // [label, foreground, background, minimum ratio]
  ['text / background',        hex(T.text),   hex(T.bg),            4.5],
  ['button text / accent',     hex(T.white),  hex(T.accent),        4.5],
  ['text-neutral / panel',     grey(T.text, 50),  hex(T.panel),     4.5],
  ['nav text / nav bg',        hex(T.nav),    hex(T.navBg),         4.5],
  ['nav text / nav bg strong', hex(T.nav),    shiftL(T.navBg, -10), 4.5],
  ['white / warning badge',    hex(T.white),  hex(T.warning),       4.5],
  ['white / error',            hex(T.white),  hex(T.error),         4.5],
  ['white / success',          hex(T.white),  hex(T.success),       4.5],
]
let failed = 0
for (const [label, fg, bg, min] of pairs) {
  const r = ratio(fg, bg), ok = r >= min
  if (!ok) failed++
  console.log(`${ok ? 'pass' : 'FAIL'}  ${r.toFixed(2).padStart(5)}  (min ${min})  ${label}`)
}
process.exit(failed ? 1 : 0)
```

Output on the current tokens (exit code 1):

```
pass  11.05  (min 4.5)  text / background
pass  11.39  (min 4.5)  button text / accent
FAIL   2.12  (min 4.5)  text-neutral / panel
FAIL   2.18  (min 4.5)  nav text / nav bg
FAIL   1.76  (min 4.5)  nav text / nav bg strong
FAIL   2.93  (min 4.5)  white / warning badge
pass   8.73  (min 4.5)  white / error
pass   4.64  (min 4.5)  white / success
```

Read the gate as a *specification*: the list of pairs is your statement of which colour combinations the design system promises are readable. Because the system derives colours, a change to `--as-color-lightness-factor` can quietly break pairs that passed yesterday, and a gate catches that on the day it happens. The design system's own contrast-checker component is the interactive version of the same idea.

**[AUTHOR NOTE: This is a natural place to show the contrast-checker component being used on the system's own tokens. A short before/after screenshot would be a very strong figure.]**

---

## Lens 3: Structure

Next, what does assistive technology actually receive? I rendered each component and dumped the resulting DOM.

### Tabs: half a pattern

```html
<as-tab-group>
  <as-tab tabindex="0" role="tab" aria-selected="true">One</as-tab>
  <as-tab tabindex="0" role="tab" aria-selected="false">Two</as-tab>
  <as-tab-panel>A</as-tab-panel>
  <as-tab-panel hidden>B</as-tab-panel>
</as-tab-group>
```

The tabs are right but incomplete. The ARIA tabs pattern needs the following, and a screen reader depends on all of it:

- tabs inside an element with `role="tablist"` (this is what axe flagged),
- panels with `role="tabpanel"`, labelled by their tab (`aria-labelledby`),
- tabs pointing to their panel (`aria-controls`),
- **roving tabindex**: only the selected tab is in the tab order (`tabindex="0"`), the others are `-1`, and arrow keys move between them. Here every tab has `tabindex="0"`, so a keyboard user must Tab through all of them.

One more behaviour is worth changing. The key handler treats pressing **Tab** as selecting the current tab (`['Space', 'Enter', 'Tab']`), so simply tabbing *past* a tab changes the visible panel.

### Panel: a heading that only responds to a mouse

```
PANEL: heading role= null  tabindex= null  aria-expanded= null
```

The collapsible panel adds a click listener to its heading, and nothing else. A keyboard user can't reach it, and a screen reader user isn't told it's expandable or whether it's open.

### Drawer: a dialog with no name

The drawer has `role="dialog"` but no accessible name and no `aria-modal`. axe reports the missing name once the drawer is open.

### Select: a combobox in disguise

The select builds a text input, a popover and a list of `li` options. The component contains no ARIA at all, so a screen reader meets an unlabeled text field (axe's `label` violation), then a list of unnamed items, each in the tab order because every option has `tabindex="0"`. It needs `role="combobox"` on the input with `aria-expanded`, `aria-controls` and `aria-activedescendant`, `role="listbox"` and `role="option"` on the list, and a label.

### Toast: two announcements fighting

```html
<div class="toast-wrapper" role="region" aria-live="polite">
  <div class="toast success" role="alert" aria-label="success"> ... Saved </div>
</div>
```

A polite live region wrapping an element with `role="alert"` (which is implicitly *assertive*) is contradictory, and a sticky toast's close button has no name at all: in a test, `aria-label` was `null` and the button contains only an icon, which the icon component hides from assistive technology. A simpler model: make the container `role="status"` (polite) for information and success, and use `role="alert"` only for errors.

### Smaller ones

- **Show/hide password** is an `<a tabindex="-1">` with no `href`, so it cannot be reached with the keyboard at all. It should be a `<button type="button">` with `aria-pressed`.
- **Graph legend items** are focusable (`tabindex="0"`) but respond only to `click`, so Enter and Space do nothing.
- **Form validation** announces its message but doesn't set `aria-invalid` on the input or link the message with `aria-describedby`.

---

## Lens 4: Behaviour

### The drawer you can't close

This is the most serious finding. Here is how a drawer closes:

```js
this.overlay = document.createElement('div')
this.overlay.classList.add('as-overlay')
...
this.overlay.addEventListener('click', e => this.closeDrawer())
//this.closebutton.focus()
```

The only way to close it is to click the overlay, which is a `div` with a click handler. The close button exists in the code, but it's commented out (together with its listener and the `focus()` call). There's no Escape handling, no focus moved into the drawer when it opens, and none returned to the button when it closes. I checked it in a test: after opening, `document.activeElement` was `BODY`.

For a keyboard user the drawer opens and can't be dismissed. That fails several criteria at once (keyboard operability, no keyboard trap, focus order), and it's the kind of defect that makes a component unusable rather than inconvenient.

### Focus styles

The stylesheets contain **22** `outline: none` (or `outline: 0`) declarations, and **zero** `:focus-visible` rules. There are 30 focus-related rules in total (the CSS writes pseudo-classes in capitals, `:FOCUS`, which is valid because pseudo-class names are case-insensitive, and which is easy to miss when you search), so some removed outlines are replaced with something else. The tab group, for example, grows an underline on focus. But without `:focus-visible`, those replacements show for mouse users too, and any removal without a replacement leaves keyboard users with no visible focus. The only reliable way to know is to Tab through every component and look.

### Motion

The CSS contains 79 transition and animation declarations, and **no `prefers-reduced-motion` rule**. People with vestibular disorders set that preference, and an interface that slides, scales and staggers regardless is a problem for them. The graph's cascading column animation, the drawer, the toast countdown and the carousel's inertia all ignore it.

There's no `forced-colors` (Windows High Contrast) or `prefers-contrast` handling either. Neither is required for basic conformance, but both are worth knowing about.

---

## The fix kit

Every fix below was applied to the real component and tested, unless marked otherwise.

### Tab group

Patches to `as-tab-group-component.js`:

- wrap the tabs in `<div role="tablist">` (created in `init()`),
- give each panel `role="tabpanel"`, an id, and `aria-labelledby` pointing at its tab, and give each tab `aria-controls`,
- roving tabindex: `-1` on all tabs, `0` on the selected one, updated in `tabAction()`,
- remove `Tab` from the keys that select a tab,
- move focus to the newly selected tab on arrow keys.

**Result:** axe's `aria-required-parent` violation is gone. The tabindex values are `0,-1,-1`, every `aria-controls` points to a panel that points back, and ArrowRight selects the second tab *and* moves focus to it.

*One caution:* the wrapper changes the DOM structure. The script's selectors were updated to find tabs inside the new wrapper, but check your stylesheets for child combinators (`as-tab-group > as-tab`) that would stop matching. The CSS I read uses descendant selectors, which survive.

### Drawer

Patches to `as-drawer-component.js`:

- restore the commented-out close button and its listener,
- add `aria-modal="true"` and an `aria-label` (taken from the button text),
- close on Escape,
- move focus to the close button once the drawer is visible, and return it to the opener on close.

**Result:** axe's `aria-dialog-name` violation is gone. Focus lands on the Close button after opening, Escape closes the drawer, and focus returns to the opener.

A fuller solution is to use a native `<dialog>` with `showModal()`, which gives you a real focus trap, Escape handling and an inert background for free. I couldn't test that here (jsdom doesn't implement `showModal`), so verify it in a real browser.

### Collapsible panel

Patches to `as-panel-component.js`: give the heading `role="button"` and `tabindex="0"`, keep `aria-expanded` in sync inside `rotateIcon()`, and toggle on Enter and Space.

**Result:** the heading gets role `button`, tabindex `0` and `aria-expanded="true"`; pressing Enter collapses the panel and `aria-expanded` becomes `false`. A cleaner option is to put a real `<button>` inside the heading, which gives you the keyboard behaviour with no handler at all.

### Toast

One line: `close.setAttribute('aria-label', 'Close notification')`. **Result:** the sticky toast's close button now has a name. (The `role="alert"` change described above is a recommendation and wasn't tested.)

### Focus rings, in tokens

Because the system is token-first, a focus ring belongs in the tokens. This is a standard pattern, and I haven't run it in a browser:

```css
:root {
  --as-focus-ring: var(--as-size-xxs) solid var(--as-color-accent);
  --as-focus-offset: var(--as-size-xxs);
}
:where(a, button, input, select, textarea, [tabindex]):focus-visible {
  outline: var(--as-focus-ring);
  outline-offset: var(--as-focus-offset);
}
```

`--as-color-accent` against the white panel is 11.39:1, which comfortably clears the 3:1 minimum for focus indicators. `:focus-visible` shows the ring for keyboard focus and hides it for mouse clicks, which resolves the usual complaint behind `outline: none`. Then search for the 22 `outline: none` rules, and for each one decide: delete it, or replace it.

### Reduced motion, in tokens

The time tokens from Chapter 2 make a clean fix possible, because duration is a variable. Also untested in a browser:

```css
@media (prefers-reduced-motion: reduce) {
  :root {
    --as-time-xs: 0s; --as-time-s: 0s; --as-time-m: 0s;
    --as-time: 0s; --as-time-l: 0s; --as-time-xl: 0s;
  }
}
```

Two caveats follow from the earlier chapters. Only 2 of the 6 time tokens are used, and **29 hard-coded durations bypass the tokens entirely**, so they would keep animating. Replace them with tokens first. Motion that JavaScript drives (the carousel's autorotate, the toast's countdown) needs its own check of `window.matchMedia('(prefers-reduced-motion: reduce)')`. Also keep in mind that "reduced" doesn't mean "none": a quick fade is usually fine, while sliding, scaling and parallax are the things to remove.

---

## Making it stick

Fixing the issues once is the easy half. These habits keep them fixed:

1. **A contrast gate** in the build (the script above) so token changes can't silently break readability.
2. **An axe test per component**, run after the component has finished rendering. A scan taken too early passes while real defects hide. The harness from Chapter 3 plus `axe.run` is about 15 lines.
3. **A keyboard checklist** for every new component: reachable with Tab, operable with Enter/Space/Escape/arrows, visible focus, no keyboard trap, focus managed when UI appears and disappears.
4. **A "semantics" lint** for the thing axe can't see: a search for `addEventListener('click'` on non-interactive elements (`div`, `span`, `li`, headings) that flags any that lack a `role` and `tabindex`.
5. **A real-device pass** before each release: one screen reader (VoiceOver or NVDA), keyboard only, 200% zoom and a phone. Automated results are a floor, and these four checks find the rest.
6. **A public conformance note.** State what the system targets (WCAG 2.2 AA is the usual aim), what has been tested and with what, and what's known to be incomplete. That honesty is also what makes the claim credible.

**[AUTHOR NOTE: Consider publishing a short accessibility statement for the design system after you've fixed the items here. It will carry weight because the book shows the audit that led to it.]**

---

## Try it

1. **Run the contrast gate** and fix the four failing pairs with the suggested tokens. Re-run until it exits cleanly.
2. **Scan every component with axe** after rendering, and add a timer so the tab group has time to initialise. How many violations do you find that this chapter didn't?
3. **Unplug your mouse** and try to open, operate and close every component in the docs site. Make a list of every place you get stuck.
4. **Apply the drawer patch**, then try a native `<dialog>` version in a real browser. Which gives better behaviour with a screen reader?
5. **Turn on "reduce motion"** in your operating system and reload the graph page. What still moves?

---

## Chapter summary

- Audit with **four lenses**: automated checks, contrast maths, structure and behaviour. Each finds problems the others can't.
- The system has real strengths (hidden decorative icons, native elements, a live region on validation, a data table for the graph), and **the core palette passes** contrast.
- axe found **3 violations**, but the serious problems are invisible to it: a drawer that **can't be closed from the keyboard**, a tab group missing half its ARIA, a panel heading that only responds to a mouse, a select with no roles or label, and an unnamed close button.
- **Derived colours need a gate.** Four secondary token pairs fail AA (nav states at 2.18 and 1.76, the warning badge at 2.93, `text-neutral` at 2.12), and a 40-line script catches them.
- Tokens make fixes cheap: **a focus ring and reduced motion both live naturally in the token layer.** Hard-coded values (22 removed outlines, 29 raw durations) are what bypass them.
- Accessibility is a process, not a status. Build the gates, keep the checklist, run the real-device pass, and say publicly what you've tested.

**That completes the audit.** The book's remaining piece, Chapter 8, covers delivery: getting the system into a real CMS, where you don't control the page, the build, or the other scripts that load alongside yours.
