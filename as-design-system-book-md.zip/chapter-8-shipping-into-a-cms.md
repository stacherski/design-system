# Chapter 8: Shipping Into a CMS You Don't Control

> **Draft 2.** The technical hazards in this chapter were tested against the AS Design System's real component files in jsdom, and the bundle sizes were measured with esbuild. The HubSpot delivery model and the generation workflow come from the author's own practice. Items marked **[AUTHOR NOTE]** are still open questions for you.

---

## The environment is the hard part

Everything so far assumed a friendly page: your scripts load in the order you wrote them, your HTML is the HTML you meant, and nothing else on the page has opinions. A CMS breaks all three assumptions.

On a CMS page:

- **You don't control load order or timing.** A tag manager, a theme script, a cookie banner and your bundle all compete, and any of them may arrive late.
- **You don't control the markup.** Editors add, remove, reorder and duplicate modules. The same component may appear zero, one or twelve times.
- **You don't control the CSS.** A theme stylesheet written years ago shares the global namespace with yours.
- **You don't control the people.** Editors will leave fields blank, paste surprising values, and use your component in a context you never imagined.

A design system built on custom elements is unusually well suited to this world, since a tag is the one thing every CMS can output. But "well suited" isn't "safe". This chapter walks through the hazards, with tests, and then leaves room for how you handle each in HubSpot.

---

## Why attributes make CMS delivery easy

Chapter 1 made a claim: configuration is attributes, so any system that can output HTML can configure a component. In a CMS that claim pays off directly. A module's editor fields map one-to-one onto attributes:

| Editor field | Becomes | Example |
|---|---|---|
| Dropdown (choice) | an attribute with fixed values | `position="right"` |
| Text | an attribute with free text | `button-text="Filters"` |
| Boolean | a presence attribute | `controls`, `markers` |
| Rich text | the element's children | `<as-drawer>…content…</as-drawer>` |
| Repeater / list | child elements | tabs and panels inside `<as-tab-group>` |

The template stays tiny, because the module just prints a tag. There's no initialisation script per module, no ID wiring and no per-instance JavaScript, since the component upgrades itself the moment the browser sees the tag.

**[AUTHOR NOTE: Show one real module here: its fields definition and its template output for a component such as the drawer or tab group. Mention how you escape editor-supplied values inside attributes (HubL's attribute-escaping filter) and why it matters given that several components put attribute text into `innerHTML` (Chapters 1 and 6).]**

---

## Three places HTML lives in a CMS

Custom elements are not equally welcome everywhere in a CMS. In HubSpot, the author's experience is that there are three places markup can come from, and they behave very differently:

| Where the HTML comes from | Custom elements? | Why |
|---|---|---|
| **Module templates** (code written by a developer) | Work fine | The template's output is rendered as written, so `<as-drawer>` reaches the browser untouched |
| **WYSIWYG / rich-text fields** (written by editors) | Stripped | The editor's HTML is sanitised, and tags the sanitiser doesn't recognise are removed, so an `<as-drawer>` pasted here disappears |
| **The Universal HTML module** (raw code block) | Work fine | Accepts arbitrary HTML, but the editing experience is poor for writing code |

This one table shapes the whole delivery strategy. It means the system's best entry point (editors typing a tag into a text field) is closed off. Components have to be placed either by a developer, inside a module template, or by someone using the raw HTML module.

The first route is the clean one: a developer builds a module whose fields map onto attributes (previous section), and editors fill in fields. The cost is a module for every component or composition, built and maintained by a developer.

The second route removes the developer, but the raw HTML module is "not really code-writing friendly": a small text box, no linting, no preview of component behaviour, and no help remembering which attributes exist. That is a real obstacle, because the audience for this route is exactly the people who *don't* want to write markup.

**[AUTHOR NOTE: Confirm the sanitisation behaviour for the book (which tags and attributes survive, and whether it differs between field types or portal settings), since readers will test it. Also say what the Universal HTML module's limits are in practice (size, whether scripts and stylesheet links are allowed in the body, how it behaves in the page editor preview).]**

---

## Delivery by generation: a skill as the last mile

The AS approach to this problem is to stop asking people to write the markup at all. Instead, a **skill** (a packaged set of instructions and reference data for Claude) knows the whole design system and does the writing.

### How it works

The documentation generated for the system (every component, its parameters, usage, events and tokens) became the skill's reference material. From any input content, such as a brief, a document or bullet notes, the skill can:

1. **Compose the page from web components**, choosing the right component for each piece of content (tabs for parallel content, a drawer for secondary detail, a gauge or graph for a figure).
2. **List the exact assets needed:** a complete set of links to the CSS and JS files for only the components that page uses.
3. **Produce copy-and-paste code** for the HTML.
4. **Write image prompts and generate illustrations**, and **source photographs from pexels.com**, packaged together as a **ZIP archive**.

The person publishing the page then does five things and writes no code:

1. Create a new page.
2. Upload the images and illustrations from the archive.
3. Add a **Universal HTML module**.
4. Paste the generated content into it.
5. Save.

That last step (save, and the page works) is the point. The skill solves the Universal HTML module's weakness from the other side: the module is hard to *write* in, but easy to *paste* into.

### Why this works: the docs became the interface

This is where Chapter 7 pays off in a way the docs site's own design didn't plan for. The documentation is **structured data**: `components.json`, `properties.json`, `events.json`, `tokens.json`, each row tied to a component name. A page for humans is one rendering of that data. A skill is another. The same facts that print a property table can tell a model that `as-drawer` accepts `position`, `button-text` and `transition-time`.

That changes how to think about documentation quality. The docs now have **two readers**, and the second one cannot guess. A person who finds a placeholder description ("This is Phone Icon token.") shrugs and tries it. A model that finds one has nothing to work from.

### What this means for the rest of the book

Several earlier findings become more serious once generation is the delivery path:

- **Docs drift becomes generation bugs.** Chapter 7 found 4 components whose counts disagree with the data, a documented "Pagination" component that doesn't exist, 4 source files with no entry, 15 undocumented tokens, and 117 of 165 token descriptions that are placeholders. A page generated from drifted docs can reference a component that isn't there, or leave out one that is. The drift-check script is no longer only housekeeping. It protects the output of the pipeline.
- **Bundle weight stops being a problem.** The per-page asset list means a page loads only the components it uses, not the 41 kB gzipped stylesheet and 26 kB script from the one-bundle model. This is the "per-module assets" model, with the list generated instead of maintained by hand. It also makes the icon-token weight from earlier more relevant, since icons are in the shared root stylesheet, and any page that loads it pays for all 79.
- **Defects in components are copied into every page.** The drawer that can't be closed from the keyboard (Chapter 9) is only a bug in one file, but the skill will happily place it on every page where a drawer is the best fit. Fixing the component fixes pages that load it by URL. Until it's fixed, it's worth teaching the skill which components not to reach for.
- **Untrusted input flows through the skill.** Content that comes from a brief, a document or pasted notes ends up inside attributes (`button-text`, `title`, graph data). Chapters 5 and 6 showed that several components put attribute text into `innerHTML` or `eval` it. The skill should escape attribute values, and the components should stop trusting them.
- **The pasted code is a snapshot.** Once markup is pasted into a module, it no longer updates. The assets, by contrast, update wherever they're linked by URL. That cuts both ways: a bug fix reaches every page immediately, and so does a breaking change. The stable public contract from Chapter 4 (attributes, events and tokens) is what keeps old pasted pages working when a component changes.

### Where this sits among the delivery models

This is a fifth model, and it needs a row in the table below: **generated, pasted Custom HTML**. It has the reach of the Custom HTML approach (no developer per page) without its usual weakness (drift and no reuse), because every page is composed from the same governed components and the same documented rules. Its weaknesses are different: manual steps (upload, paste), snapshots of markup, and a dependency on the quality of the docs data.

**[AUTHOR NOTE: This section is the heart of the chapter, so the book needs the details only you have:**
**- Where do the component CSS and JS files live (HubSpot file manager, your docs site, a CDN), and are the URLs pinned to a version or always the latest?**
**- How do the generated pages refer to the uploaded images (file manager URLs, relative names), and what does the user have to change after uploading?**
**- Do the script and stylesheet links go inside the Universal HTML module, and how did you handle the page-load timing hazard described below?**
**- A short example is worth a lot: one short brief, the generated page, and a screenshot of the result.**
**- What went wrong the first time, and what rules did you add to the skill because of it?]**

---

---

## Test the documented examples

Pasted pages are snapshots, so a component release can break markup that was fine yesterday, and nobody notices until a page looks wrong. The system already has the raw material for a safety net: **67 documented examples** in `examples.json`, each a piece of markup that is promised to work. Rendering all of them against every new build is a regression suite.

This script loads every component into jsdom, renders each example, and reports any that throw or contain a tag that never gets defined. I ran it against the repository:

```js
// examples-smoke.mjs: render every documented example and report what breaks
import { JSDOM, VirtualConsole } from 'jsdom'
import fs from 'fs'

const examples = JSON.parse(fs.readFileSync('src/_data/examples.json', 'utf8'))
const dir = 'src/assets/js/components/'
const sources = fs.readdirSync(dir).filter(f => f.endsWith('-component.js'))
                  .map(f => fs.readFileSync(dir + f, 'utf8'))
const sleep = ms => new Promise(r => setTimeout(r, ms))
let bad = 0

for (const ex of examples) {
  const errors = new Set()
  const vc = new VirtualConsole()
  vc.on('jsdomError', e => errors.add(e.detail?.message || e.message))
  const { window: w } = new JSDOM(`<!doctype html><html lang="en"><body><main>${ex.example || ex.code}</main></body></html>`,
    { url: 'https://example.test/', runScripts: 'outside-only', pretendToBeVisual: true, virtualConsole: vc })
  w.crypto.randomUUID ??= () => 'id' + Math.random().toString(36).slice(2)
  w.AS = {}
  Object.defineProperty(w.HTMLElement.prototype, 'innerText', { get() { return this.textContent }, configurable: true })
  for (const src of sources) { try { w.eval(src) } catch (e) { errors.add('load: ' + e.message) } }
  w.document.dispatchEvent(new w.Event('DOMContentLoaded'))
  await sleep(40)
  const tags = new Set([...w.document.querySelectorAll('main *')].map(e => e.localName).filter(n => n.startsWith('as-')))
  for (const t of tags) if (!w.customElements.get(t)) errors.add(`<${t}> is never defined`)
  if (errors.size) { bad++; console.log(`- ${ex.componentName}: ${[...errors].map(e => e.slice(0, 80)).join(' ; ')}`) }
  w.close()
}
console.log(`\n${examples.length} examples, ${examples.length - bad} clean`)
process.exit(bad ? 1 : 0)
```

On the current repository: **67 examples, 59 clean**. The 8 that reported problems are instructive, because most aren't component defects:

- **Tab Group:** `<as-tab-panel>` is never defined, as Chapter 7 noted.
- **Command menu:** the example refers to global variables (`locale`, `options`) that the snippet doesn't define, which is the `eval` design showing through: the example isn't self-contained.
- **Carousel:** the example contains a literal `[slides]` placeholder, so it isn't runnable markup.
- **Class Toggle (5 reports):** jsdom printed "Could not parse CSS stylesheet" for the class toggle examples. I didn't trace it, and it may be a jsdom limitation, so treat it as unverified.

That makes the suite useful twice. It guards against regressions, and it also tells you which documented examples **aren't real**, which matters a lot when the skill and your readers copy them. Making every example runnable is a good cleanup before using the suite as a gate.

Two limits are worth stating. It checks that things render without throwing, and it can't see appearance, so a layout change or a colour change passes. A visual comparison step (screenshots of each example, diffed against the last release) is the natural next layer. And it only covers documented usage, so any pasted page that uses undocumented attributes isn't protected. **A corpus of real, previously generated pages** is an even better test set.

---

## Delivery models

There are four common ways to get the components onto a CMS page. Each trades control against simplicity:

| Model | How | Strength | Weakness |
|---|---|---|---|
| **One bundle in the theme** | `components.js` and `components.css` load on every page | Simple, cached once, components just work everywhere | Every page pays for every component |
| **Per-module assets** | Each module loads only the component(s) it needs | Pay only for what's used | Many requests, and shared code (icon, select) must be deduplicated |
| **External hosting (CDN)** | Files hosted elsewhere, referenced by URL | Update without touching the CMS | An extra dependency, with versioning and caching on you |
| **Inline / Custom HTML** | Markup pasted into an editor-owned block | No developer needed | Hand-written, it means no reuse, no governance and easy drift |
| **Generated, pasted Custom HTML** | A skill composes the page from components and outputs code plus a per-page asset list | No developer per page; consistent, governed output; loads only what the page uses | Manual upload and paste steps; markup is a snapshot; quality depends on the docs data |

The AS system's own docs site already hints at the first and the last: the build produces a single `components.js` and `components.css`, and every component page offers its JS and CSS as a **single-file download**, which is the raw material for per-module delivery.

**[AUTHOR NOTE: The first two models cover your module work, and the last covers the generation workflow. State which you use for which kind of page, and why.]**

### How heavy is it?

Whichever model you pick, you should know the weight. I bundled the 29 JS files and 25 CSS files with esbuild, minified:

| Asset | Minified | Gzipped |
|---|---|---|
| All component JS | 122.6 kB | **26.2 kB** |
| All component CSS | 170.8 kB | **40.9 kB** |

The largest single component is the graph at about 24 kB minified, then the date picker (10 kB), the multi-select (6.6 kB) and the search menu (6.4 kB). A page that uses none of those pays for them anyway under the one-bundle model.

The more surprising finding is in the CSS. **The 79 icon tokens are about 73 kB of the unminified CSS (34% of it), and about 23 kB of the 41 kB gzipped total** when compressed on their own, roughly half of what the browser downloads for styling. Each icon is a base64 SVG inside a custom property (Chapter 2), and every page loads all of them whether it shows one icon or none. If your CMS pages are performance-sensitive, this is the first thing to look at: split the icons into their own stylesheet, load only the ones a page needs, or move the less common ones into per-module files.

A tested build detail that helps here: esbuild can wrap a bundled stylesheet in a cascade layer straight from the import. In my test, `@import "./a.css" layer(as);` produced `@layer as { .btn { color: red } }`. That leads to the next hazard.

---

## Hazard 1: Late loading

Every component registers itself like this:

```js
document.addEventListener('DOMContentLoaded', () => {
    if (window.customElements.get('as-drawer') === undefined) { /* define it */ }
})
```

That's fine when the script is loaded with `defer` in the page head. But `DOMContentLoaded` fires **once**. If your bundle arrives after it has fired, because a tag manager injected it, a theme loader lazy-loaded it, or a script was added with `async` and happened to finish late, the listener is added to an event that has already happened, and **the components never register**.

I tested exactly this. With the event already fired, then the drawer script run:

```
defined: false | rendered buttons: 0
```

The page silently shows unstyled, unenhanced tags with no error in the console. That's the worst kind of failure in a CMS, because it only happens on some pages, on some loads, depending on timing.

The fix is the standard "ready" check:

```js
const boot = () => { /* ...register the component... */ }
if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot)
else boot()
```

I patched the drawer this way and tested both cases:

```
after load:    defined: true, buttons: 1
while loading: defined: false, then true once DOMContentLoaded fires
```

This hazard is especially relevant when markup and asset links are pasted into a Universal HTML module in the page body, where script and stylesheet timing may differ from a normal theme setup. Always test the generated page the way an editor would produce it.

The same change belongs in every component file (25 of them use the `DOMContentLoaded` wrapper; the tab group and the Toast/Copy helpers don't, so they're unaffected). If you adopt the shared base class from Chapter 4, you can put this check in one place.

---

## Hazard 2: Hidden dependencies

Chapter 3 pointed out that `as-toast` and `as-copy` read `window.AS.Toast`, and `window.AS` is created in `main.js`, not in the component files. In a CMS where you load the component bundle without the docs site's `main.js`, the first line of the toast throws. I confirmed it:

```
TypeError: Cannot read properties of undefined (reading 'Toast')
```

The fix is one line at the top of each file that uses the namespace: `window.AS = window.AS || {}`. It's easy to find these by testing each component on a blank page, which is the single most valuable CMS pre-flight check you can do.

---

## Hazard 3: Loading twice

CMS pages often include the same asset twice: once from the theme, once from a module that "needs" it. This one the system already handles well. Every component is guarded with `if (window.customElements.get(name) === undefined)`, and I tested loading the drawer script twice, with the result:

```
error: none | buttons: 1
```

Calling `customElements.define` twice with the same name throws, so this guard is what makes duplicate inclusion harmless. It is a small habit that pays off hugely in a CMS, and it's worth saying so in the book.

---

## Hazard 4: The CSS you didn't write

This hazard comes from the light DOM decision (Chapter 1). Because components don't use Shadow DOM, their CSS is global, and so is the theme's. Two things collide:

- **Generic class names.** In `base-component.css`, I counted **42 unprefixed top-level class selectors**, including names like `.flex`, `.box`, `.square`, `.full-width`, `.container-inline-size` and `.colorbox`. A theme with its own `.box` or `.flex` will fight with them.
- **Bare element selectors.** The root stylesheet styles `body`, headings, links and tables directly, which is acceptable for the docs site and rude on someone else's page.

There are three ways to contain this:

1. **Prefix everything** with `as-`, which is the same convention the tokens already follow. Safe but tedious to retrofit.
2. **Cascade layers.** Wrap the system's CSS in a layer (`@layer as { ... }`). Under the cascade rules, *unlayered* styles beat layered ones regardless of specificity, so the theme's CSS wins any conflict and your defaults act as a floor. As noted above, the build can do this with `@import "./x.css" layer(as)`. I tested the bundling step and the output, but not the visual cascade, since jsdom doesn't implement layers, so check this in a browser.
3. **Scope to an attribute or wrapper**, for example styling only inside `[as-scope]`, so the reset never leaks to the rest of the page.

**[AUTHOR NOTE: What collisions have you actually hit on profitroom.com or in a HubSpot theme? Which of these three did you choose? Real examples of a clash would be the most persuasive thing in this section.]**

---

## Hazard 5: Editors do unexpected things

You can't test with every editor input, so components need to degrade gracefully. Three cases from the codebase:

- **A missing attribute shouldn't crash.** The command menu calls `this.getAttribute('keys').split('+')`, which throws if the attribute is absent (Chapter 5). An editor who forgets one field takes the whole menu down.
- **Elements added later must still work.** Editors preview, rearrange and sometimes insert modules dynamically. I tested adding an `<as-drawer>` to the page *after* the component was defined, and it rendered correctly, which is the custom elements model working in your favour: the browser upgrades any matching tag the moment it appears.
- **Duplicates must not collide.** Twelve drawers on one page each need their own IDs. The components generate them with `crypto.randomUUID()`, which works, but throws on a non-secure origin (plain `http://`, such as a staging site or a LAN preview). A one-line fallback (Chapter 4) removes the trap.

A useful rule for any component that will be edited by non-developers: **the component's defaults must produce something sensible from an empty tag.** Test `<as-drawer></as-drawer>`, `<as-graph></as-graph>` and `<as-tab-group></as-tab-group>` with nothing inside them.

### Security in an editable environment

Chapter 5 flagged `eval()` on attribute values, and Chapter 6 flagged titles written through `innerHTML`. In a developer-only codebase those are low risk. In a CMS they're real, because the attribute values come from editors, and sometimes from content imported or pasted from elsewhere. A site with a Content Security Policy that forbids `unsafe-eval` can't run the command menu at all. Treat every attribute as untrusted input, and fix those two before shipping to a CMS.

**[AUTHOR NOTE: Does Profitroom (or your HubSpot portal) enforce a CSP, and how did that shape what you shipped?]**

---

## Versioning and caching

Once components are on live pages, you can't change them casually, since every page that loads them changes at once. Three practices keep this manageable:

1. **Version the asset URLs** (a version number or a content hash in the filename) so a release is a deliberate switch, and browsers and CDNs can cache aggressively.
2. **Use semantic versioning on the public contract** from Chapter 4: attributes, events and tokens are the promise. Internal DOM is not.
3. **Keep a changelog** that names attributes and events that were added, deprecated or removed, since those are the things CMS templates depend on.

A subtlety specific to CMS: templates (the HTML that prints your tags) and assets (the JS and CSS) are deployed separately and can get out of sync. A template that emits a new attribute before the new JavaScript has reached every cache gives you a window where the attribute is ignored. Graceful defaults help here: a template that gets ahead of its assets should still render something sensible.

Unversioned URLs also depend on caching: files linked without a version are cached by browsers and any CDN in front of them, so a release (or a mistake) takes time to reach every visitor. Check how your files are served and what cache lifetime they get.

**[AUTHOR NOTE: How do you version and publish the theme assets, what is your process for rolling out a component change across pages, and have you been bitten by a template/asset mismatch?]**

---

## A small bonus: build warnings are bug reports

While bundling the CSS for the size measurement above, esbuild printed a warning about `as-char-counter-component.css`:

```
Cannot use type selector "span" directly after nesting selector "&"
    16 │     &span {
```

That is a real defect. In CSS nesting, `&span` isn't valid, and a browser that follows the spec will **ignore the rule**, so the style it was meant to apply never appears. The correct form is `& span` or `:is(span)`. Nobody had noticed because the build "succeeded".

Turn build warnings into a visible report, or into failures. Warnings that scroll past on every build teach everyone to ignore warnings.

---

## A pre-flight checklist

Before any component goes into a CMS, run it through this:

- [ ] Loads **alone** on a blank page, with no other scripts
- [ ] Works when loaded **twice**
- [ ] Works when the script runs **after** `DOMContentLoaded` has fired
- [ ] Works when the tag is **added to the page later**
- [ ] Renders something sensible from an **empty tag**
- [ ] Handles a **missing or malformed attribute** without throwing
- [ ] Safe with **hostile attribute values** (no `eval`, no `innerHTML` with attribute text)
- [ ] Doesn't break on **plain HTTP** (`crypto.randomUUID` fallback)
- [ ] Its CSS is **prefixed or layered** and doesn't restyle the host page
- [ ] Appears **12 times** on one page without ID or listener collisions

---

## Try it

1. **Reproduce the late-load bug.** Load `components.js` with a script tag that you add from the console after the page has loaded. Which components fail to register? Apply the `readyState` check and repeat.
2. **Test on a blank page.** Make an HTML file that loads one component file and nothing else. Do this for every component and write down the ones that fail.
3. **Measure your own icons.** How much of your CSS are inline icons? Try splitting them into a second stylesheet and compare page weight.
4. **Add the layer.** Change the build's `@import` lines to use `layer(as)`, then load the page inside a CMS theme with its own stylesheet. Which rules now lose to the theme, and is that what you wanted?
5. **Break it as an editor would.** Output each component with an empty tag, a missing attribute and a value containing `"><script>`. Fix whatever breaks.

---

## Chapter summary

- A CMS is an environment you **don't control**: load order and timing, markup, CSS and people. Custom elements suit it because a **tag is the one thing every CMS can output**, and attributes map directly onto editor fields.
- Tested hazards: **late loading** (components never register if the script runs after `DOMContentLoaded`, fixed by a `readyState` check), **hidden dependencies** (`window.AS` throws without `main.js`), **double loading** (already handled by the registration guard), and **late-added tags** (work correctly).
- **CSS is the biggest collision risk** because of the light DOM. Contain it with prefixes, cascade layers (which esbuild can emit from the import) or an attribute scope.
- Weight matters: the full bundle is **26 kB of JS and 41 kB of CSS gzipped**, and **inline icons are roughly half of the compressed CSS**.
- Assume editors will surprise you: components must degrade gracefully, and **attribute values must be treated as untrusted input**.
- Version the public contract, keep a changelog, and **treat build warnings as bug reports**.

---

## Closing the book

If you've followed the chapters in order, you've seen the same ideas return in different clothes: tokens as named decisions, components that enhance rather than replace, a small public contract, and cleanup that someone has to write on purpose. The system in this book is not finished, and no honest design system is. What makes it worth learning from is that it's built in the open, from the platform up, and that its author is willing to audit it in public.

**[AUTHOR NOTE: This is the place for your own closing. What would you do differently if you started again, and what should a reader build first?]**
