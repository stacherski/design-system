# Chapter 6: The Graph Component: 945 Lines of JavaScript and 936 of CSS

> **Draft 1.** Code comes from the AS Design System repository. Behaviour described as "tested" was reproduced in jsdom or Node, and the helper functions proposed here were run before inclusion. Items marked **[AUTHOR NOTE]** are places for your own story.

---

## The biggest file in the system

`as-graph-component.js` is 945 lines, nearly a fifth of all the JavaScript in the design system. Its stylesheet is 936 lines, almost exactly the same length. That symmetry is the most important fact about it, and this chapter is mostly an explanation of why.

The component draws two kinds of chart, **columns** (with an optional line drawn on top) and **pies**, from a block of JSON data. It supports animated transitions, a data table, a legend, hover and focus tooltips, paging through a long series, resizing the visible window, and **drill-down**: clicking a pie slice or column opens a second level of data underneath it.

You use it like this:

```html
<as-graph controls markers data-data='{
  "title": "Bookings by year",
  "charttype": 1,
  "resolution": 3,
  "step": 4,
  "data": [
    { "label": "2022", "value": 5 },
    { "label": "2023", "value": 8 },
    { "label": "2024", "value": 3 }
  ]
}'></as-graph>
```

That's a lot of behaviour for a single tag, and because it's built from native HTML, CSS and SVG with no charting library, it's also a good place to see what charting *is*.

---

## How data gets in

### One attribute, one JSON object

Every other component takes many small attributes. The graph takes one big one, `data-data`, which holds a JSON object with the title, chart type, resolution, step, palette and the data itself. The documentation lists eleven properties for the component, but only three are real attributes: `data-data` itself, plus the flags `controls` and `markers`. The other eight (`data`, `resolution`, `step`, `charttype`, `title`, `xtitle`, `ytitle`, `palette`) are *keys inside that JSON*.

That's a sensible choice. Chart configuration is nested (a data array, a palette array, and for drill-down, data inside data points), and flat string attributes can't hold that shape.

### The attribute is the state

The component declares `data-data` as an observed attribute:

```js
static get observedAttributes() { return ["data-data"] }

attributeChangedCallback(name) {
    if (name === 'data-data') {
        clearTimeout(this.resolutionTimeout)
        this.prevData = []
        this.resolutionTimeout = setTimeout(() => this.start(), this.transitionDuration)
    }
}
```

So the way to update a chart is to **set the attribute again**. The built-in `fetchData()` does exactly that: it downloads a JSON file and writes it into the attribute:

```js
const json = await response.json()
this.setAttribute('data-data', JSON.stringify(json))
```

The attribute is the single source of truth, and everything redraws from it. That has real advantages. There's one way to feed the chart, it works from markup, from a script or from a CMS, and you can *see* the current data in dev tools. The `clearTimeout` debounces rapid updates, so ten quick changes cause one redraw.

The cost is that large datasets get serialised into an attribute and parsed again every time. Which brings us to the first thing worth fixing.

### Parsing the same JSON eight times

Look at `start()`:

```js
this.data       = JSON.parse(this.getAttribute('data-data')).data
this.resolution = Math.min(Number(JSON.parse(this.getAttribute('data-data')).resolution), ...)
this.step       = Number(JSON.parse(this.getAttribute('data-data')).step) || 5
this.chartType  = (Number(JSON.parse(this.getAttribute('data-data')).charttype)) ? ...
this.palette    = (JSON.parse(this.getAttribute('data-data')).palette) ? JSON.parse(...)...
this.chartTitle = JSON.parse(this.getAttribute('data-data')).title
this.chartX     = JSON.parse(this.getAttribute('data-data')).xtitle
this.chartY     = JSON.parse(this.getAttribute('data-data')).ytitle
```

It parses the whole attribute at least eight times to read eight keys. For three data points that's invisible. For a thousand it's wasteful, and it makes the code harder to read. The fix is one line and one destructuring:

```js
const cfg = JSON.parse(this.getAttribute('data-data') || '{}')
const { data = [], title, xtitle, ytitle, palette = [] } = cfg
this.data = data
this.step = Number(cfg.step) || 5
this.resolution = Math.min(Number(cfg.resolution), data.length) || data.length
```

Parse once, name the result, read from the object. A related habit is to wrap the parse in `try/catch`, so one stray comma in a CMS field produces an empty chart and a console message instead of an exception.

---

## JavaScript computes, CSS draws

This is the central design idea, and the reason the CSS file is as long as the JavaScript.

Look at how a column is created. The JavaScript doesn't draw anything. It computes a number and hands it to CSS as a custom property:

```js
column.style.setProperty('--height', 100 * value / maxY + '%')
column.style.setProperty('--transition-delay', (i - this.index) * this.transitionDelay + 'ms')
column.style.setProperty('--_color', col)
```

The stylesheet owns everything visual: the shape, the colour, the hover state and the animation. A column is just an element whose height is `var(--height)`, with a CSS `transition` on `height` and `opacity`. When the data changes, the script updates the property, and the browser animates the change.

The pie works the same way. Each slice is an element, and JavaScript supplies angles and positions as properties (`--stop1`, `--stop2`, `--rotate1`, `--rotate2`, `--x`, `--y`, `--scale`), while CSS turns those numbers into a wedge.

This split has real benefits:

- **Animation is free.** Staggered entrance (each column delayed by `--transition-delay`) is a CSS transition, not a JavaScript animation loop. The browser handles the timing. (Animating `height` triggers layout, so it isn't the cheapest property to animate, but at this scale it's fine.)
- **Theming is free.** The columns use the same design tokens as the rest of the system. Change `--as-color-accent` and the chart follows.
- **States are free.** Hover, focus and `animate` are CSS selectors, not event-handler code.
- **It's inspectable.** Every bar is a real element you can select in dev tools.

And a real cost:

- **Many DOM nodes.** A chart with hundreds of points creates hundreds of elements, plus tooltips and legend items. Canvas or a single SVG would handle a large dataset better. This component is built for the tens-of-points scale that dashboards usually need, and its `resolution` setting (how many points are shown at once) exists partly to keep the node count down.

The line chart is the one exception, and it's worth looking at on its own.

---

## The smooth line

When the columns have a line on top, the line can't be a set of `div`s. It's an SVG `<path>`, created with the correct namespace:

```js
const smoothSvg = document.createElementNS('http://www.w3.org/2000/svg', 'svg')
const path = document.createElementNS('http://www.w3.org/2000/svg', 'path')
```

The curve through the points comes from a six-line function:

```js
generateSmoothPath(points) {
    if (points.length < 2) return ''
    const d = [`M ${points[0].x} ${points[0].y}`]
    for (let i = 0; i < points.length - 1; i++) {
        const p0 = points[i], p1 = points[i + 1]
        const cp1x = (p0.x + p1.x) / 2, cp1y = p0.y
        const cp2x = (p0.x + p1.x) / 2, cp2y = p1.y
        d.push(`C ${cp1x} ${cp1y}, ${cp2x} ${cp2y}, ${p1.x} ${p1.y}`)
    }
    return d.join(' ')
}
```

Each segment is a cubic Bézier curve. Both control points sit at the **horizontal midpoint** between the two data points. The first has the *first* point's height and the second has the *second* point's height. The result is an S-shaped curve that leaves each data point flat and arrives at the next one flat.

That choice has a lovely mathematical property. The curve's height at any parameter `t` is a weighted average of only the two endpoint heights, with weights that are never negative:

```
y(t) = y0 · ((1−t)³ + 3(1−t)²t)  +  y1 · (3(1−t)t² + t³)
```

So the curve **can never go above the highest point or below the lowest**. I checked it numerically on four points ranging from 10 to 80, and the curve's range was exactly 10.00 to 80.00. This is why the line never "overshoots" and dips below zero between points, which is the classic flaw of naive spline smoothing (Catmull-Rom and similar curves). For a business chart, where an overshoot would suggest a value that never existed, it's the right trade. The price is a curve that always flattens at each data point instead of flowing through it.

### Percentages, then pixels

One more detail makes the line responsive. The points are stored as **percentages** of the chart's width and height, and converted to pixels only when drawing:

```js
convertPercentagePointsToPixels(percentPoints, width, height) {
    return percentPoints.map(p => ({ x: p.x / 100 * width, y: p.y / 100 * height }))
}
```

On resize, `recalculateSVGPoints()` measures a hidden `.proxy` element and regenerates the path `d` attribute from the same percentages. The data never has to be recomputed, only re-projected. Storing coordinates in a size-independent unit and projecting at the last moment is a standard technique, and it's worth borrowing.

---

## Drill-down and the level stack

Clicking a column, a pie slice or a legend item with nested data opens a second level. Data points can contain their own `data` array, and `drilldown()` swaps it in:

```js
drilldown(label, data, index) {
    // store current level so we can come back
    this.prevData[this.level] = { data: this.data, resolution: this.resolution, label, index, title: ... }
    this.level += 1
    this.data = data.data
    this.resolution = this.data.length
    this.index = 0
    ...
}
```

`prevData` is a **stack of levels**. Going down pushes the current view onto it; the "up" button pops it and restores the saved data, resolution and index. The button's label even uses the saved parent's name (`↩ 2024`). It's the same shape as a browser's back history, in about twenty lines.

### The graph uses the select

The controls panel contains `<as-select>` elements (for chart size and chart type), so the graph is a **consumer of its own system**. Whenever the list of sizes changes after a drill-down, it rebuilds the native `<select>` options and then uses the command from Chapter 5:

```js
this.resolutionSelect.closest('as-select').setAttribute('updated', '')
```

That's the attribute-as-command pattern working exactly as designed, and it shows why the pattern exists. The graph doesn't hold a reference to any select object. It sets an attribute and the select rebuilds itself. Components that compose through the DOM don't need to know each other's internals.

---

## What the graph gets right about accessibility

Charts are among the hardest things to make accessible, because the information is spatial. The graph does one thing that most chart libraries skip: it **offers the data as a real table**.

```js
<table id="datatable_${this.graphId}" class="table">
```

A "show data table" checkbox toggles it. Every chart has an equivalent that a screen reader, a keyboard user or someone who simply prefers numbers can read row by row. The SVG points also carry `<title>` elements, which show native tooltips and are exposed to assistive technology. The tooltips listen for both `pointerenter` and `focus` (the component defines the pair `["pointerenter", "focus"]`), which is the right intent for keyboard users. The data table also gets export actions for free, because the component composes `<as-table-actions>` beside it.

One keyboard gap is easy to miss: the legend items are focusable (`tabindex="0"`) but trigger drill-down on `click` only. Pressing Enter or Space on a focused `div` doesn't fire a click, so keyboard users can reach the legend but can't drill down with it. Making the items `<button>` elements would fix that.

What's missing is the **framing**. There are no ARIA attributes anywhere in the file. The chart area has no `role` and no label, so a screen reader meets a pile of unnamed `div`s. A minimal improvement:

```js
this.figure.setAttribute('role', 'img')
this.figure.setAttribute('aria-label',
    `${this.chartTitle}: ${this.data.map(d => `${d.label} ${d.value}`).join(', ')}`)
```

For a short series, this reads the whole chart aloud in one sentence, and the data table remains for anyone who wants detail. We'll return to this in Chapter 9.

---

## Problems worth fixing

### A listener for every redraw

`start()` is where the chart is built, and it registers two listeners every time it runs:

```js
window.addEventListener('resize', () => { this.recalculateSVGPoints() })
this.addEventListener('as-graph:drawcomplete', (e) => { this.removeAttribute('busy') })
```

And `start()` runs more often than you'd expect. I loaded a chart in jsdom and counted `resize` registrations:

```
after first render:      2 resize listeners
after 1 data update:     3
after 2 data updates:    4
```

There are two things going on. First, the chart starts **twice on load**: once from `connectedCallback` and once because setting the initial `data-data` attribute triggers `attributeChangedCallback`. Second, each later data change adds one more permanent listener, and none are removed. A dashboard that refreshes its charts every few seconds accumulates thousands of resize handlers, each of which re-measures and regenerates paths for charts that may be long gone.

The fix is the `AbortController` pattern from Chapter 3. Create one controller per `start()`, abort the previous one first, and add `disconnectedCallback`:

```js
start() {
    this.abort?.abort()
    this.abort = new AbortController()
    window.addEventListener('resize', () => this.recalculateSVGPoints(), { signal: this.abort.signal })
    // ...
}
disconnectedCallback() { this.abort?.abort() }
```

The double start deserves its own guard: skip `connectedCallback`'s call if the attribute change will trigger one anyway, or debounce both through the same timeout.

### Titles go in as HTML

The chart's title and busy text are inserted through a template literal and `innerHTML`:

```js
${this.chartTitle ? `<div class="charttitle">${this.chartTitle}</div>` : ''}
```

If the JSON can come from somewhere untrusted (an API, a CMS field, a query string), a title like `<img src=x onerror=...>` runs script. Because the data arrives as a single attribute, this is an easy path to overlook. Build the element and set `textContent` instead.

### A comparison that never compares

The function that picks the top of the Y axis ends with:

```js
let modulo = maximum % 2
return (modulo = 0) ? maximum - modulo : maximum
```

`(modulo = 0)` is an **assignment**, not a comparison. It assigns zero and evaluates to zero, which is falsy, so the function always returns `maximum` and the rounding logic never runs. I confirmed it: for values 5, 8 and 3 the result is 9.6 (the data maximum times 1.2), exactly the value before the "rounding" step. This is one character away from working (`===`), and it's the standard reason to turn on a linter rule against assignments in conditions.

### Ugly axis numbers

The value that does come out, 9.6, then feeds the axis labels, which divide it into steps:

```
max 9.6, 5 steps → 0.0  1.9  3.8  5.8  7.7  9.6
```

Those labels are technically correct and visually strange. People expect an axis that reads 0, 2, 4, 6, 8, 10. The uneven increments (1.9, 1.9, 2.0, 1.9, 1.9) are rounding artefacts from `toFixed(1)`. A chart should choose a "nice" maximum and step first, then derive the ticks.

The standard approach is short enough to include in full. I wrote and tested it:

```js
function niceScale(maxValue, tickCount = 5) {
    if (maxValue <= 0) return { max: 1, step: 0.2, ticks: [0, .2, .4, .6, .8, 1] }
    const rough = maxValue / tickCount
    const mag   = 10 ** Math.floor(Math.log10(rough))     // power of ten
    const frac  = rough / mag
    const step  = (frac <= 1 ? 1 : frac <= 2 ? 2 : frac <= 5 ? 5 : 10) * mag
    const max   = Math.ceil(maxValue / step) * step
    const ticks = []
    for (let i = 0; i * step <= max + step / 1e6; i++) ticks.push(+(i * step).toPrecision(12))
    return { max, step, ticks }
}
```

Results:

```
niceScale(9.6)   → max 10,   ticks 0, 2, 4, 6, 8, 10
niceScale(14.4)  → max 15,   ticks 0, 5, 10, 15
niceScale(7.2)   → max 8,    ticks 0, 2, 4, 6, 8
niceScale(0.9)   → max 1,    ticks 0, 0.2, 0.4, 0.6, 0.8, 1
niceScale(1234)  → max 1500, ticks 0, 500, 1000, 1500
```

It picks a step from the sequence 1, 2, 5, 10 times a power of ten, which is the set of increments people find natural. It also returns the maximum so the tallest column never touches the top, which is what the `× 1.2` in the original was trying to achieve.

**[AUTHOR NOTE: This is a good place for a screenshot pair, the same chart before and after `niceScale`. Readers will see the difference immediately.]**

### Hard-coded strings

The default busy text is Danish (`'Rendering af graf...'`), while the controls are hard-coded English (`↩ UP 1 LEVEL`, `LEFT`, `PREV`, `NEXT`). The command menu showed the right answer in Chapter 5: put every string in a `locale` object and accept it as configuration. A chart is a particularly bad place to bake in a language, because charts get embedded in many pages.

---

## Making the graph testable

All of the problems above would have been caught by tests, but the component can't easily be tested as written. Everything is a method on an element, and the methods read `this.querySelector(...)` and `getBoundingClientRect()` as they go.

The way out is to separate the **maths** from the **DOM**. The geometry is already nearly pure:

| Function | Pure? | Input → output |
|---|---|---|
| `generateSmoothPath(points)` | Yes | points → SVG path string |
| `convertPercentagePointsToPixels(...)` | Yes | points, size → points |
| `getYAxisMaxValue` | Almost | values → number |
| `getSumFromIndex` | Almost | data, index → number |

Move these into a plain module with no `this` and no DOM, and each becomes a one-line test:

```js
import { niceScale, smoothPath } from './graph-math.js'

console.assert(niceScale(9.6).max === 10)
console.assert(smoothPath([{x:0,y:0}]) === '')
console.assert(smoothPath([{x:0,y:0},{x:10,y:10}]).startsWith('M 0 0 C'))
```

The custom element then becomes a thin shell: read the attribute, call the maths, write custom properties. The effect is the same one this book keeps arriving at: the more of a component you can express as plain functions, the easier it is to trust.

---

## Try it

1. **Count the listeners.** Update a chart's `data-data` ten times in a loop, then use `getEventListeners(window)` in dev tools. How many `resize` handlers are there? Apply the `AbortController` fix and count again.
2. **Swap the scale.** Replace the Y-axis computation with `niceScale` and compare the chart before and after on three different datasets.
3. **Fix the comparison.** Change `(modulo = 0)` to `(modulo === 0)`. Does the axis change? (Then ask whether the rounding rule it protects is even the right rule.)
4. **Label the chart.** Add the `role="img"` and `aria-label` snippet and test it with a screen reader. Is the sentence useful for a 12-point series? What would you do instead?
5. **Parse once.** Refactor the eight `JSON.parse` calls into one, and time `start()` with a 5,000-point dataset before and after.

---

## Chapter summary

- The graph is built from **HTML, CSS and a little SVG**, with no charting library. **JavaScript computes numbers and CSS draws them**, which is why the stylesheet is as long as the script.
- Data enters through **one JSON attribute** that is also the component's state. Setting it again redraws the chart, which is simple and works from anywhere, but the JSON is parsed many times and rendered titles go through `innerHTML`.
- The **smooth line** uses Bézier control points at each segment's midpoint, so the curve is a weighted average of its endpoints and **can never overshoot** the data.
- **Drill-down** is a stack of saved levels, and the controls reuse `<as-select>` through the attribute-command pattern from Chapter 5.
- The **data table** alternative is the component's best accessibility feature, and the **missing label** on the chart is its biggest gap.
- Tests surfaced real defects: **a resize listener added on every redraw**, **a double start on load**, **an assignment where a comparison belongs**, and **axis labels that aren't "nice"**.
- Separating the **maths from the DOM** makes a component testable.

**Next:** Chapter 7 steps outside the components to the documentation site itself: how Eleventy, JSON data files and Pagefind turn 25 components into a living documentation site, and how to keep the docs from drifting away from the code.
