# Chapter 3: Small Components, Big Lessons

> **Draft 1.** Code comes from the AS Design System repository. Every bug described here was reproduced in a test (jsdom), and every proposed fix was run against the original code. Items marked **[AUTHOR NOTE]** are places for your own story.

---

## Why start small

The best way to learn how a component system really behaves is to read its smallest parts. Thirteen of the components in this system are under 105 lines each:

| Component | Lines | What it does |
|---|---|---|
| `as-tab` | 34 | A tab label with an optional icon |
| `as-toast` | 67 | Transient notifications |
| `as-gauge` | 61 | A circular progress gauge |
| `as-char-counter` | 69 | Counts characters and text-message segments |
| `as-class-toggle` | 72 | A button that toggles classes anywhere in the page |
| `as-icon` | 74 | Renders an icon token |
| `as-show-hide-password` | 79 | Reveals a password field |
| `as-popout` | 87 | A popover with an anchored trigger |
| `as-drawer` | 87 | A slide-in panel with an overlay |
| `as-dot-matrix-clock` | 88 | A live clock drawn with dots |
| `as-form-validation` | 91 | Friendly validation messages |
| `as-panel` | 98 | A collapsible panel |
| `as-tab-group` | 103 | Tabs and panels, with keyboard support |

Small code has a useful property: you can hold all of it in your head. That makes it the ideal place to see which habits are paying off and which ones are quietly causing trouble. This chapter is organised around five lessons, each drawn from real code in the system.

---

## Lesson 1: Not everything should be a custom element

Look at how you use two of the small components:

```html
<as-drawer position="right" button-text="Filters">...</as-drawer>
```

```js
new Toast('Saved', { type: 'success', timeout: 3000 })
```

The drawer is a tag. The toast is a **class**, called from JavaScript. That isn't an inconsistency; it's a correct decision about two different kinds of UI.

A drawer is **content that lives on the page**. You write it where it belongs in the markup, and it has a trigger and a body. A toast is an **event with a lifetime**. Nobody writes a toast into the HTML. Code *emits* one in response to something happening, and it disappears. Forcing a toast into a tag would mean inserting an element, waiting for it to render and removing it, all to imitate a function call.

The system has two such imperative helpers, `Toast` and `ASCopy` (the click-to-copy helper), and both attach themselves to a shared namespace:

```js
if (!window.AS.Toast) {
    class Toast { ... }
    window.AS.Toast = Toast
    window.Toast = Toast
}
```

**The rule:** declarative things that exist on the page become tags. Imperative things that happen in response to events become functions.

### A hidden dependency

Look at the first line again: `window.AS.Toast`. If `window.AS` doesn't exist, that line throws. And `window.AS` is created in a *different file*, `main.js`:

```js
window.AS = window.AS || {}
```

So the toast works only if `main.js` loads first. That's invisible from reading the toast file, and it breaks the promise from Chapter 1 that a component is one self-contained file. It's easy to fix: put `window.AS = window.AS || {}` at the top of every file that uses the namespace. It costs one line and removes a load-order trap.

Hold on to the broader point: **self-containment is a property you have to test, not just claim.** The simplest test is to load each component alone on a blank page.

---

## Lesson 2: `connectedCallback` runs more than once

In Chapter 1 we saw `as-tab` protect itself with a `ready` flag. Here is what happens to a component that doesn't. The drawer's `connectedCallback`:

```js
connectedCallback() {
    this.drawerId = this.getAttribute("id") || crypto.randomUUID()
    ...
    this.settings.content = this.innerHTML   // capture my own children
    this.broadcastEvent('as-drawer:created', ...)
    this.render()                            // replace them with a button + wrapper
}
```

The component reads its own `innerHTML` as "the content", then overwrites `innerHTML` with a new structure that includes that content. On first run that's fine. But the browser calls `connectedCallback` every time the element is attached, including when you **move** it:

```js
document.querySelector('#other-container').append(drawer)
```

I ran this in a test. Before the move, the drawer has one button and one panel. After the move:

```
before move: buttons 1, drawers 1
after move:  buttons 2, drawers 2
```

The second run captured the already-rendered markup (button and panel included) as its "content", then wrapped it again. The result is a duplicated trigger and a drawer nested inside a drawer.

Any app that reorders the DOM triggers this: drag-and-drop lists, tabs that re-parent their panels, framework re-renders that move nodes instead of recreating them.

### The fix

It's the same two lines `as-tab` already uses:

```js
connectedCallback() {
    if (this.ready) return
    this.ready = true
    // ...rest unchanged
}
```

With that guard, the same test gives `buttons 1, drawers 1` after the move.

### The same bug in a different costume

The gauge has a variation. It reads its value from its own text:

```js
this.settings.value = this.getAttribute('val') || this.textContent || 50
```

and then replaces its own contents with two empty `<div>`s. On a second connection `textContent` is whitespace, so the value is lost. (In my test, a gauge showing `80` came back with a blank `data-value` after a move.)

**The pattern to remember:** a component that **reads from its own children and then rewrites them** needs an idempotency guard, every time. If you write one rule on a wall for your team, make it this one.

**[AUTHOR NOTE: Have you hit a re-parenting bug like this in production, perhaps in a HubSpot page where modules are rearranged? A real story here would be the strongest paragraph in the chapter.]**

---

## Lesson 3: Clean up what you start

Components that listen to the outside world have to stop listening when they leave. That means `window` events, timers and anything else that outlives the element. Searching the whole codebase for `disconnectedCallback` finds it in only a handful of files. The rest never clean up.

### Who does it right

The clock stops its timer when removed:

```js
disconnectedCallback() {
    if (this._interval) clearInterval(this._interval)
}
```

The carousel is the most thorough, removing its resize, pointer and wheel listeners and clearing its interval. These are the models to copy.

### Who leaks

**The toast** starts a one-second countdown and never stops it:

```js
setInterval(() => {
    val--
    gauge.querySelector('div:first-child').style.setProperty('--gauge-value', val)
    ...
}, 1000)
setTimeout(() => toast.remove(), this.timeout + 1000)
```

The toast element is removed after its timeout, but the interval keeps firing forever, updating an element that is no longer on the page. In my test, creating one toast produced one `setInterval` call and zero `clearInterval` calls. An app that shows a toast per action will accumulate a timer for each one.

**The popout and the panel** each add a `window` resize listener in `init()` and never remove it. Each instance on a page adds one permanent listener, and removing the component from the DOM doesn't take it away.

### The subtle one: cleanup code that doesn't clean

The form validation component *tries* to do the right thing, and gets it wrong in an instructive way:

```js
#bindEvents() {
    this.#input.addEventListener('blur', this.#handleBlur.bind(this))
}
#unbindEvents() {
    this.#input.removeEventListener('blur', this.#handleBlur)
}
```

`.bind(this)` creates a **new function** every time it's called. `removeEventListener` removes a listener only if you pass the *same function* you added. These are two different functions, so the removal silently does nothing. I confirmed it: after the element was removed from the page, blurring its input still produced a validation message.

### Two clean patterns

The first is to keep a reference to the bound function:

```js
constructor() {
    super()
    this.onBlur = this.#handleBlur.bind(this)   // one function, stored
}
connectedCallback()    { this.#input.addEventListener('blur', this.onBlur) }
disconnectedCallback() { this.#input.removeEventListener('blur', this.onBlur) }
```

The second is shorter and harder to get wrong. Use an **`AbortController`**. Every listener registered with its signal is removed by a single `abort()`:

```js
connectedCallback() {
    this.abort = new AbortController()
    const { signal } = this.abort
    this.#input.addEventListener('input', () => this.clear(), { signal })
    this.#input.addEventListener('blur',  () => this.check(), { signal })
    window.addEventListener('resize', () => this.layout(), { signal })
}
disconnectedCallback() {
    this.abort.abort()      // removes all three
}
```

For a design system with 25 components, adopting the `AbortController` pattern everywhere is probably the highest-leverage cleanup you can make. It works for `window`, `document` and element listeners alike.

---

## Lesson 4: Use the platform's features before writing your own

Three of the small components show the payoff of leaning on browser features instead of reimplementing them.

### The popout uses the Popover API and anchor positioning

```js
this.innerHTML = `
    <button style="anchor-name: --${this.popoutId}"
            popovertarget="${this.popoutId}">...</button>
    <div popover id="${this.popoutId}"
         style="position-anchor: --${this.popoutId};"></div>`
```

The `popover` attribute gives you open/close behaviour, light dismiss (clicking outside closes it), top-layer rendering and focus handling for free. CSS anchor positioning (`anchor-name` and `position-anchor`) ties the panel to its button without a line of positioning JavaScript. This is the work that "popper" libraries exist to do.

The caveat is browser support. The Popover API is widely available, but anchor positioning arrived more recently and support differs between browsers, so check your own support matrix. Using new platform features is a bet on where browsers are heading, and a design system should state the bet openly in its documentation.

### The form validation uses the Constraint Validation API

Instead of writing validation rules, the component reads the browser's own `input.validity` state (`valueMissing`, `tooShort`, `patternMismatch`, and so on) and maps each to a message supplied by an attribute:

```html
<as-form-validation value-missing="Please enter your email">
    <input type="email" required>
</as-form-validation>
```

The author declares the rules with ordinary HTML attributes (`required`, `type`, `pattern`, `minlength`). The component only decides *how errors are shown*. It also adds an `aria-live="polite"` region so that screen readers hear the message. This is the right division of labour: the browser knows what's valid, and the component knows how to talk about it.

It's also the one component that uses **private class fields** (`#input`, `#errorMessage`, `#handleBlur`). Those are truly private, unlike the `_underscore` convention used elsewhere. They prevent outside code from depending on internals, which is exactly what you want from a component with a public attribute API.

### The tab group uses ARIA roles and keyboard handling

`as-tab-group` is the most mature small component. It sets `role="tab"`, maintains `aria-selected`, supports arrow keys for navigation, and carries comments that explain *why*:

```js
// Use :scope to limit to DIRECT children only.
// Without this, a nested as-tab-group's tabs would also be matched.
this.tabs = this.querySelectorAll(':scope > as-tab')
```

and:

```js
connectedCallback() {
    // Defer so child elements are fully parsed before init runs.
    Promise.resolve().then(() => this.init())
}
```

That second one fixes a real custom-element hazard. When the browser's parser creates a custom element, `connectedCallback` can fire **before the element's children have been parsed**. Deferring `init()` by one microtask waits for them. Several other components in the system read their children in `connectedCallback` directly, and could use the same trick.

---

## Lesson 5: Small bugs hide in small code

Small components feel safe, so they get less scrutiny. The password toggle is a good illustration, because its bug does not stop it working:

```js
this._buttonListenerID = this.showhide.addEventListener('click',
    e => this.showhidepass(e).bind(this))
```

Read it carefully. The handler **calls** `showhidepass(e)` immediately. That function toggles the field's type, as intended, and returns `undefined`. Then the handler tries `undefined.bind(this)`, which throws. In my test, one click toggled the field from `password` to `text`, and also logged `TypeError: Cannot read properties of undefined (reading 'bind')`.

So the feature works and every click produces a console error. Nothing visible is wrong, which is why this kind of mistake survives for years.

There are two more problems in the same file:

- The cleanup method is spelled `disconnectedCalback`, with a missing `l`. The browser never calls it, and it refers to a variable that doesn't exist.
- The `throw new Error(...)` in the `catch` block comes before the line that dispatches the error event, so that event can never fire.

### The fix

Using the `AbortController` pattern from Lesson 3:

```js
this.abort = new AbortController()
this.showhide.addEventListener('click',
    e => this.showhidepass(e),
    { signal: this.abort.signal })
```

```js
disconnectedCallback() {
    this.abort?.abort()
}
```

I applied this to the original file and ran it. The field toggles `password`, `text`, `password` on three clicks. There are zero errors, and after the element is removed, clicks no longer do anything.

### Typos that tests catch

A misspelled lifecycle method is not a compiler error, because `disconnectedCalback` is just another method name. The only protection is a test. That leads to the practical takeaway of this chapter.

---

## Try it: a lifecycle test in 20 lines

You don't need a browser or a test framework to check the bugs above. This harness loads a component into jsdom, fires `DOMContentLoaded`, and lets you poke at the result:

```js
const { JSDOM } = require('jsdom')
const fs = require('fs')

function load(file, html) {
  const dom = new JSDOM(`<!doctype html><body>${html}</body>`, { runScripts: 'outside-only' })
  const w = dom.window
  w.crypto.randomUUID ??= () => 'id-' + Math.random().toString(36).slice(2)
  w.AS = {}                                           // namespace shim
  w.eval(fs.readFileSync(file, 'utf8'))
  w.document.dispatchEvent(new w.Event('DOMContentLoaded'))
  return w
}

// Test: moving a drawer must not duplicate it
const w = load('as-drawer-component.js',
  '<div id="b"></div><as-drawer id="d"><p>Hello</p></as-drawer>')
const d = w.document.getElementById('d')
w.document.getElementById('b').append(d)
console.assert(d.querySelectorAll('button').length === 1, 'drawer duplicated on move')
```

Run it with `npm i jsdom` and `node test.js`. On the original drawer the assertion fails. With the `ready` guard it passes.

**Exercises**

1. Write the same "move it" test for the gauge, popout and panel. Which ones survive?
2. Add a `disconnected` test: remove the element, then dispatch the events it was listening to, and assert nothing changes.
3. Replace the toast's `setInterval` with a CSS animation plus an `animationend` listener, which needs no timer at all. Is the countdown still accurate?

---

## A checklist for small components

Pin this next to your editor:

- [ ] Registration is guarded (`customElements.get(...)`).
- [ ] `connectedCallback` starts with `if (this.ready) return`.
- [ ] Every listener on `window`, `document` or an outside element uses an `AbortController` signal and is aborted in `disconnectedCallback`.
- [ ] Every timer is cleared on disconnect.
- [ ] Text from attributes goes through `textContent`, not `innerHTML`.
- [ ] The file works on a blank page, with no dependency on another file.
- [ ] A lifecycle test covers move, remove and double-load.

---

## Chapter summary

- **Tags for things on the page, functions for things that happen.** The drawer is a tag and the toast is a class, which is the right split. Make sure shared namespaces (`window.AS`) are created in every file that needs them.
- **`connectedCallback` runs more than once.** A component that reads its own children and rewrites them needs an idempotency guard. The drawer and gauge lack one, and `as-tab` shows the fix.
- **Clean up what you start.** Clear timers and remove listeners in `disconnectedCallback`. `.bind()` creates a new function, so the removal in the form validation component does nothing. Use `AbortController` and the problem disappears.
- **Lean on the platform.** Popover, anchor positioning, Constraint Validation, private fields and `:scope` replace code you would otherwise write and maintain.
- **Small code still needs tests.** A misspelled lifecycle method and a stray `.bind` both ship happily until a test looks for them.

**Next:** Chapter 4 steps back from individual components to the conventions that tie all 25 together: how attributes and events are named, why 15 files carry their own copy of the same helper, and when a shared base class is worth the cost.
