# Chapter 7: Documentation Is the Product

> **Draft 1.** Facts come from the AS Design System repository. The drift-check script and the template fix in this chapter were run against the real data and templates. Items marked **[AUTHOR NOTE]** are places for your own story.

---

## Nobody adopts what they can't read

A design system with perfect components and poor documentation will lose to a worse system that explains itself. People don't adopt code. They adopt what they can understand in the five minutes they're willing to spend before trying something else.

The AS Design System understood this early. It ships as a **living documentation site**, and the site is more than a README with screenshots. Every component has its own page with live examples, a property table, an event table, and downloads for its source files. This chapter looks at how the site is built, what it does well, where it has started to drift from the code, and how to stop that drift automatically.

---

## One template, many pages

The site has no hand-written component pages. Here is the whole of the file that produces all 26 of them:

```yaml
---
pagination:
  data: components
  size: 1
  alias: component
permalink: "/components/{{ component.slug }}/"
layout: layouts/component.njk
eleventyComputed:
  title: "{{ component.name }}"
---
```

That's Eleventy's **pagination as a page generator**. Given a data file, `components.json`, with 26 entries, it produces 26 pages, one per entry, each at `/components/{slug}/`. The layout it points at is a single template that knows how to render any component.

That template pulls three more datasets and filters each down to the current component:

```njk
{% set componentExamples = examples   | byComponent(component.name) %}
{% set componentProps    = properties | byComponent(component.name) %}
{% set componentEvents   = events     | byComponent(component.name) %}
```

`byComponent` is a one-line filter defined in `eleventy.config.js`:

```js
eleventyConfig.addFilter("byComponent", (collection, componentName) =>
    collection.filter(item => item.componentName === componentName))
```

The data model is flat and easy to explain:

| File | One row is... | Rows |
|---|---|---|
| `components.json` | a component | 26 |
| `examples.json` | a usage example | 67 |
| `properties.json` | an attribute | 105 |
| `events.json` | an event | 51 |
| `tokens.json` | a design token | 165 |
| `tokenCategories.json` | a token group | 11 |

Rows relate to components through `componentName`. This is a tiny relational database in JSON files, and it carries a large advantage: **adding a component to the docs is a data change, not a design change.** Add a row, and the page, the sidebar entry, the tabs and the search index all follow.

### Why data and not Markdown?

Many documentation sites write one Markdown file per component. That reads well in an editor and drifts badly over time, because nothing guarantees that every page lists the same sections in the same order. Structured data forces consistency: every component has exactly the same four tabs, and an empty tab doesn't render at all (`{% if componentEvents.length %}`).

The trade-off is authoring comfort. A property description with HTML in a JSON string is unpleasant to edit, which is why some descriptions contain raw `<br/>` and `<code>` tags. A good compromise is to keep the structure in data but allow Markdown in the text fields, rendered by a filter.

**[AUTHOR NOTE: Why JSON files instead of front matter or Markdown? Was it the CMS mindset, with data in one place that someone could edit through a UI?]**

---

## The docs eat their own cooking

Open the component template again and look at what the page is made of:

```html
<as-tab-group>
  <as-tab icon-name="inbox" selected>Examples (5)</as-tab>
  <as-tab-panel>
    <as-table-actions data-table=".examples"></as-table-actions>
    <as-table-sort omit="0" sort>
      <table class="examples equal table">...
```

The documentation is **built out of the components it documents**: `as-tab-group` for the tabs, `as-table-sort` for the sortable tables, `as-table-actions` for the CSV, Excel and Markdown export buttons, `as-search-menu` for search, `as-class-toggle` for the mobile menu, and `as-dot-matrix-clock` in the sidebar.

This practice is called **dogfooding**, and it's the single best quality filter a design system has. If a component is awkward, the person writing the docs feels it first. If a component breaks, the docs break. Every page of the site is a smoke test.

Dogfooding also explains something from earlier chapters. The tab group is the most carefully written small component in the system, with ARIA roles, keyboard handling and explanatory comments, and it is also the one that every single docs page depends on.

There are two costs to be aware of:

- **Blind spots.** A bug the docs site doesn't trigger stays hidden. The docs never *move* a drawer in the DOM, so the duplicate-on-move bug from Chapter 3 isn't visible there. Dogfooding finds the bugs your own use cases find.
- **Coupling.** If every doc page uses `as-tab-group`, a regression there takes the whole site down. That's the price of eating your own cooking, and it's usually worth it.

One small detail: `<as-tab-panel>` is used on every page but never registered as a custom element. The browser treats it as a plain unknown element, and the tab group finds it with the selector `:scope > as-tab-panel` and toggles its `hidden` attribute. That works, but a registered (even trivial) element would let you add `role="tabpanel"` and `aria-labelledby` in one place. Chapter 9 returns to this.

---

## Examples: one fact stored three times

Each example in `examples.json` has three fields that all describe the same snippet:

```json
{
  "example":   "<as-drawer><p>Content</p></as-drawer>",
  "code":      "<as-drawer><p>Content</p></as-drawer>",
  "codeToken": "<code class=\"token icon\">&lt;as-drawer&gt;&lt;p&gt;Content&lt;/p&gt;&lt;/as-drawer&gt;</code>"
}
```

The template renders `example` as live HTML in one column and `codeToken` in the other. Three copies of the same information is a classic drift risk, and I checked how much of it is redundant:

- In **66 of 67** examples, `codeToken` is just the escaped form of `code`. It can be generated.
- In **30 of 67** examples, the live `example` is identical to `code`. It can be derived too.
- In the other 37, the live version differs from the shown code, because the example needs wrapper markup or setup that would only distract in the snippet. That's a legitimate reason for a separate field.

So `codeToken` should never be hand-written, and `example` should be written only when it differs. The template change is small:

```njk
<td>{{ (ex.example or ex.code) | safe }}</td>
<td><code class="token icon">{{ ex.code | escape }}</code></td>
```

Nunjucks' built-in `escape` filter does the HTML-escaping the data file currently stores by hand. After this change, an author writes one field (`code`) for the common case and a second (`example`) only when it needs to differ. Hand-escaped HTML in JSON is also error-prone: one missed `&lt;` and a code sample renders as a live element.

---

## Search without a server

Search is `as-search-menu` in the sidebar, which hands off to a `/search/` page powered by **Pagefind**. Pagefind's model is the right one for a static site: **index at build time, search in the browser, no server**. The Eleventy config runs it after every build:

```js
eleventyConfig.on("eleventy.after", async function ({ dir }) {
    const pagefind = await import("pagefind");
    const { index } = await pagefind.createIndex();
    await index.addDirectory({ path: dir.output });
    await index.writeFiles({ outputPath: path.join(dir.output, "pagefind") });
})
```

It deletes the stale index first, so removed pages can't linger in results, and the layout uses two attributes to control what's indexed: `data-pagefind-body` on the main content and `data-pagefind-ignore` on the navigation, so sidebar links don't pollute every search result.

### The brittle part

The search page does something clever and fragile. It renders Pagefind's own UI, **hides its input field**, and drives it from a custom one by copying the value across and dispatching a synthetic event:

```js
const pagefindSearchInput = document.querySelector('.pagefind-ui__search-input')
pagefindSearchInput.style.display = 'none'
searchInput.addEventListener('input', e => {
    pagefindSearchInput.value = e.target.value
    pagefindSearchInput.dispatchEvent(new Event('input', { bubbles: true }))
})
```

It works, but it depends on Pagefind's internal class names (`.pagefind-ui__search-input`), which aren't a public API, so an upgrade can break it silently. Pagefind also exposes a JavaScript API that skips the prebuilt UI entirely: import the module, call `search()`, and render the results yourself, which you'd do with your own components. That removes the hidden-input trick and the extra stylesheet.

Two smaller observations on the same area:

- The base layout loads `pagefind-ui.js` and its CSS on **every page**, but only the search page uses them. The search page then loads the script **again**.
- The page URL carries the query (`/search/?search=...`), so searches are linkable, which is a nice touch for sharing results.

---

## The build

`eleventy.config.js` is about 130 lines, and nearly everything in it is something you've met already:

1. **Before each build,** delete the old bundles (and source maps).
2. **Bundle** every `*-component.js` and `*-component.css` with esbuild into one `components.js` and one `components.css`. Sourcemaps in dev, minified in production.
3. **Run Eleventy** to generate the pages.
4. **After each build,** run the Pagefind indexer.

Discovery by filename is the convention that holds it together. Dropping `as-foo-component.js` and `as-foo-component.css` into the folders adds the component to the bundle with no registry to edit.

Two things deserve attention.

**The Docker and package setup.** The `dockerfile` starts from `node:latest`, which means a rebuild next year may silently use a different major version of Node. `package.json` also lists `"node": "^25.8.1"` as a *dependency*, which installs an npm package that ships a Node binary into `node_modules`. That is not how you pin a runtime. Use an `engines` field and an exact tag (`FROM node:22-alpine`) so builds are reproducible.

**The license.** `README.md` has an MIT badge. `package.json` says `ISC`. There is no `LICENSE` file in the repository. For a project that people copy files out of (and the docs site literally offers single-file downloads of each component), the license is part of the product. Pick one, state it once, and include the file.

---

## Where the docs drifted

Everything above makes it easy to write documentation. What it doesn't do is *check* it. The following findings came from running a script over the data files:

| Check | Result |
|---|---|
| Hand-entered counts vs actual rows | 4 of 26 components disagree (Drawer, Icon, Popout, Relative Time) |
| Documented file exists | `SVG to Base64` points to a file name that doesn't exist |
| Source file has a docs entry | 4 files have none (contrast, copy, svg-to-base, window) |
| Documented component exists | "Pagination" has properties documented but no component |
| Declared tokens documented | **15** declared tokens missing |
| Token descriptions | **117 of 165** are placeholders ("This is Phone Icon token.") |
| Event descriptions | **44 of 51** are the same generic sentence |

None of these is surprising. This is what documentation looks like after a year of fast development. The count mismatches are particularly instructive: `components.json` stores `examplesCount`, `propertiesCount` and `eventsCount` by hand, even though the three other files can produce the numbers instantly. Anything a machine can calculate should be calculated.

### A drift check in 40 lines

Here's a script that finds all of the above. It's the same idea as the convention checker in Chapter 4, applied to docs. I ran it against the repository:

```js
// check-docs.mjs: fail the build when documentation drifts from the code
import fs from 'fs'

const read = f => JSON.parse(fs.readFileSync(`src/_data/${f}.json`, 'utf8'))
const components = read('components'), examples = read('examples')
const properties = read('properties'), events = read('events'), tokens = read('tokens')
const jsDir = 'src/assets/js/components/'
const cssText = fs.readFileSync('src/assets/css/components/as-tokens-component.css', 'utf8')
const count = (list, name) => list.filter(x => x.componentName === name).length
const problems = []
const fail = msg => problems.push(msg)

// 1. Hand-entered counts must match the data
for (const c of components) {
  for (const [key, list] of [['examplesCount', examples], ['propertiesCount', properties], ['eventsCount', events]]) {
    const actual = count(list, c.name)
    if (c[key] !== actual) fail(`${c.name}: ${key} says ${c[key]}, data has ${actual}`)
  }
}
// 2. Every documented file must exist, and every component file must be documented
const files = fs.readdirSync(jsDir).filter(f => f.endsWith('-component.js'))
const documented = new Set(components.map(c => c.componentJS))
for (const c of components) if (c.componentJS && !files.includes(c.componentJS)) fail(`${c.name}: ${c.componentJS} does not exist`)
for (const f of files) if (!documented.has(f)) fail(`${f}: no documentation entry`)
// 3. Properties and events must belong to a real component
const names = new Set(components.map(c => c.name))
for (const n of new Set([...properties, ...events].map(x => x.componentName))) if (!names.has(n)) fail(`documented component "${n}" does not exist`)
// 4. Every declared token must be documented, and no placeholder descriptions
const declared = [...cssText.matchAll(/(--as-[a-z0-9-]+)\s*:/g)].map(m => m[1])
const documentedTokens = new Set(tokens.map(t => t.token))
for (const t of declared) if (!documentedTokens.has(t)) fail(`token ${t} is declared but not documented`)
const placeholders = tokens.filter(t => /^This is /.test(t.description)).length
if (placeholders) fail(`${placeholders} token descriptions are placeholders`)

console.log(problems.join('\n') || 'docs OK')
console.log(`\n${problems.length} problem(s)`)
process.exit(problems.length ? 1 : 0)
```

On the repository it reports **26 problems**: 4 count mismatches, 1 missing file, 4 undocumented source files, 1 phantom component, 15 undocumented tokens, and 1 summary line about the placeholder descriptions.

Hook it into the build, and documentation drift becomes a failing check instead of a slow decay. A good first rollout is to run it in **warning mode** for a month, fix the backlog, and then make it blocking.

### Generate what you can

A stronger move is to stop typing facts that the code already contains. Three candidates:

1. **Counts.** Compute `examplesCount`, `propertiesCount` and `eventsCount` in an Eleventy data file instead of storing them.
2. **Token values.** `tokens.json` already stores a `computedValue` for each token. Generate that field from the CSS, and keep only the human-written description by hand. Then the docs can't disagree with the stylesheet.
3. **Event names.** Extract `broadcastEvent('as-...')` names from the source (as the script in Chapter 4 did) and compare them with `events.json`. Earlier I found seven emitted events that aren't documented.

---

## Docs now have a second reader

There is a consequence of the structured-data approach that the site's design didn't plan for. Because the documentation is data (components, properties, events, tokens, each row tied to a component name), it can be read by something other than a person.

In practice, the AS system's documentation has been turned into the reference for a Claude **skill** that composes whole web pages from the components. The skill reads the same facts that print the property tables: which attributes `as-drawer` accepts, what events it fires, which tokens exist. Chapter 8 describes the workflow in full.

This raises the stakes for everything in this chapter. A person who meets a placeholder description shrugs and experiments. A model has nothing else to go on. A documented component that doesn't exist (the phantom "Pagination") becomes a component the skill can place on a page that has no code for it. So the drift check below is not only housekeeping. It protects the output of every page the skill generates.

It also changes what "good documentation" means. For machine readers, the valuable fields are the ones people tend to skip: precise types, allowed values, defaults, what is required, and **when to use one component instead of another**. A short "use this when / not when" line per component is worth more to a generating skill than another paragraph of description.

**[AUTHOR NOTE: What fields did you have to add to the documentation so the skill could choose well, and which components does it still misuse?]**

---

## A template bug, and the lesson in it

The sidebar highlights the current section with an `active` attribute. For top-level items it works. For the second level (the token categories), there's this condition:

```njk
{% if page.url and page.url.startsWith('/design-tokens/{{ cat.slug | lower }}') %}active{% endif %}
```

It looks right. But inside a Nunjucks tag, `'...{{ cat.slug | lower }}...'` is an ordinary string literal. The `{{ }}` inside it isn't evaluated, so the code is testing whether the URL starts with the **literal text** `/design-tokens/{{ cat.slug | lower }}`. It never does. I rendered both forms against the page `/design-tokens/space/`:

```
current: (nothing active)
fixed:   [A:Space]
```

The fix is string concatenation instead of interpolation:

```njk
{% if page.url and page.url.startsWith('/design-tokens/' + (cat.slug | lower)) %}active{% endif %}
```

The lesson isn't about Nunjucks. A template that doesn't fail is not a template that works. Static sites make this easy to miss, because a wrong condition produces plain, valid HTML that just *lacks* a highlight. The remedy is to treat the rendered HTML as testable output. A build step that loads a few generated pages and asserts that `[active]` appears on the right link takes ten lines.

---

## Try it

1. **Run the drift check** on the repository and fix the four count mismatches by computing them.
2. **Remove `codeToken`.** Apply the two-line template change, delete the field from `examples.json` with a script, and confirm all pages still render the same.
3. **Fix the sidebar** and add a build-time assertion that exactly one second-level item is active on `/design-tokens/space/`.
4. **Replace the hidden-input trick.** Use Pagefind's JavaScript API to render search results with your own components.
5. **Pin Node.** Add `engines` to `package.json`, change the Dockerfile to an exact tag, and remove the `node` dependency.

---

## Chapter summary

- Documentation is the product. The AS site generates **26 component pages from one template** and a handful of JSON files, so every component has the same tabs for examples, properties, events and files.
- The docs are **built from the components themselves**, which makes every page a smoke test, though it only finds the bugs the docs happen to trigger.
- **Store each fact once.** Examples hold the same snippet three times, and 66 of 67 `codeToken` values are generated by escaping `code`. Counts stored by hand have already drifted.
- **Pagefind** gives build-time static search with no server, and the one fragile part is a hidden-input hack that depends on internal class names.
- Documentation drifts. In this repo, **117 of 165 token descriptions are placeholders**, 15 declared tokens are missing, and four files and one phantom component don't match. A **40-line script** makes these failures visible.
- Pin your tooling (Node version, Docker tag) and state your license once.
- A template can be wrong while still rendering valid HTML, so **test the rendered output**.

**Next:** Chapter 8 covers the other half of shipping: getting the system into a real CMS, where you don't control the page, the build, or the other scripts that load alongside yours.
